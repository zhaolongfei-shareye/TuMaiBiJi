const poster = require('../../utils/poster.js')
const profileCloud = require('../../utils/profileCloud.js')
// 改名片那一层（图片／名称／一句话）的标记在 templates/card-info-sheet.wxml，收数据与推格在
// utils/cardInfo.js——站长 10-21 把这一屏上面那三块收进标题右侧那一枚按钮，走的就是首页同一份实现。
const cardInfo = require('../../utils/cardInfo.js')
const posterTemplates = require('../../utils/posterTemplates.js')
const api = require('../../utils/api.js')
const { t, texts } = require('../../utils/i18n.js')

// 画布自己的显示宽度，必须和 profile.wxss 里 .cell-canvas 的 width 是同一个数。
// 之前这里填的是 320——那是格子的外宽，含内边距。拿它折算高度等于把每张预览纵向
// 拉长 750/675≈11%，圆形头像在小样里被画成椭圆，而成品海报是对的：预览骗人。
const THUMB_W = 288
// 小样圆角。app.wxss 里 --r-chip 是 28rpx，但真机上原生画布不吃 CSS 圆角，
// 所以这个值还要再画进位图一次（见 poster.clipRounded）。
// 28 在这一档是安全的：换算到位图是 73 单位，验-海报模板几何.js 最后一段把十个模板
// 乘六种笔记都量过，最不利的一格离弧还留着余量（分享页那一排更窄，同一档会咬到字，
// 所以那边收到 20）。改这个数要跟着改 profile.wxss 的 .cell-canvas，尺子会核。
const THUMB_R = 28
// 十格同屏，每格都按 750 全尺寸开位图要吃三十多兆显存，低端安卓会直接崩画布。
// 小样只是挑样式，0.46 倍落笔在 320rpx 的格子里看不出差别。
const THUMB_SCALE = 0.46
// 量高度用的临时画布：排版只依赖字体度量，跟画布多大无关，所以给一张小的就够。
// （以前是 750×2600，那已经超出部分机型的单画布上限。）
const MEASURE_H = 750

// 格子的骨架：先有 id 和占位高度，画布节点得先存在，小样才画得上去。
function groupSkeleton(lang) {
  // 站长 10-04：分组名后面要带一个数（经典款（4）/ 个性款（6））。数一律现算，一个都不写死
  // ——以后加一套或撤一套，改的是那张表，这一行自己跟着变。
  // P0-5 起这份"表"是**合并后的**那份（`poster.templateList()`＝包内 ∪ 下发）：
  // 服务端多一套，这里就跟着多一格；把那一套收成 archived，数字自己掉下来。写死成 4/6
  // 就等于把"不走发版"这条承诺在界面上先兑掉一半。
  // 括号跟着语言换：英文态写成 "Classic (4)"，全角括号夹在英文里像没排完。
  // 合进 label 而不是另起一个字段：下面 renderThumbs 重画十格时只往回带 id/label/items，
  // 单独那个数会被它抹掉（表现是画完小样之后括号当场消失）。
  return poster.TEMPLATE_GROUPS.map((g) => {
    const items = poster.templateList().filter((x) => x.group === g.id).map((x) => ({
      id: x.id,
      label: poster.templateLabel(x.id, lang),
      h: Math.round((THUMB_W * 4) / 3),
    }))
    const n = items.length
    return {
      id: g.id,
      label: poster.groupName(g.id, lang) + (lang === 'en' ? ` (${n})` : `（${n}）`),
      items,
    }
  })
}

Page({
  data: {
    lang: 'zh',
    t: texts('zh'),
    themeClass: '',
    groups: groupSkeleton('zh'),
    // 弹窗那四个键（cardInfoOpen/ciSlots/ciName/ciSlogan）由 cardInfo.initial() 给初值：
    // 页面自己写死一份就会与首页那一层漂开。
    ...cardInfo.initial(),
  },

  onLoad() {
    const app = getApp()
    // 上一回挑完没落盘的、或者中途被系统杀掉留下的那些张，本机里已经没人认得它们了；
    // 先按这一页手上的名单收一遍，再按"这台手机存过哪些头像文件"的名单扫一遍。
    poster.dropUncommitted()
    poster.pruneAvatars()
    const lang = app.globalData.userInfo?.language || 'zh'
    // 小样要等骨架落到视图层之后再画，否则按选择器取不到画布节点
    this.setData(
      {
        lang,
        t: texts(lang),
        themeClass: app.applyTheme(app.getWallpaper()),
        groups: groupSkeleton(lang),
      },
      () => this.renderThumbs()
    )
    // 站长 10-16 夜（附真机图）「最顶上的都改为"设置"，他们是设置的二级菜单」⇒ 这一栏不再报
    // 自己那一格的名字，改报它挂在谁下面（左上角那行大字才报"这是卡片模板"）。
    // 键吃 `pillSettings`＝「我的」那一屏顶上那一栏用的同一枚，不新起字串。
    app.setNavTitle('pillSettings', lang)
    // 下发那一路（P0-5）：进这一页就后台拉一次配方。放在 onLoad 而不是 onShow——
    // 这一页故意不吃 onShow 重绘（下面那条注释说的就是它），而每次从「我的」走进来
    // 都是一次新的 onLoad，所以"改一条配方、不重启就看到新样子"这条够用。
    // 拉不到、被 401 拦、接口报错，一律当"这次没拿到"：包内那十套照样画，
    // 「生成笔记卡片」那枚按钮没有一条路径会因为这里而变灰。
    this._pullTemplates()
  },

  // 返回那份报告（{accepted, rejected, error}）只给尺子看；界面不因为它弹任何东西——
  // 用户不需要知道"这批配方是下发的还是包内的"，他只需要卡片一直画得出来。
  _pullTemplates() {
    const before = poster.remoteSignature()
    return posterTemplates.refresh(() => api.getPosterTemplates()).then((rep) => {
      if (!rep || rep.error || poster.remoteSignature() === before) return rep
      // 号没变就不重画那十格：拉一次是几十 KB 的网，重画十格是十个原生画布，后者贵得多。
      const groups = groupSkeleton(this.data.lang)
      this.setData({ groups }, () => this.renderThumbs())
      return rep
    })
  },

  // 这里故意没有 onShow：从相册回来时真机会补发一次 onShow，那时候读一遍 storage
  // 会把用户刚填还没保存的名称、slogan 冲掉（新建页选完图没反应就是这个成因）。
  // 形象那一块不受这条影响——它是即时生效的，重读 storage 读到的就是刚写进去的。

  // 十格小样要的那份：名称/一句话只住在 storage 里，头像取「卡片」那张
  // （posterProfile 里现算，见 utils/poster.js 那条注释——直接 readProfile 会让小样没头像）。
  // 10-30 这一屏不再挑模板 ⇒ 那份 `template` 也不再从页面状态盖进去：画哪一套由循环里的
  // `tpl.id` 说了算，十格本来就各画各的，这一枚键在这一屏已经没有读者。
  draftProfile() {
    return poster.posterProfile()
  },

  async renderThumbs() {
    // 两遍重画会打架：连点两次换图，前一遍解码头像慢、后落盘，界面就停在旧内容上
    // （实测过一次：头像已经去掉了，画布上却又把旧头像画回来）。每轮领一个号，
    // 落盘前对号，号不对的那轮直接放弃。
    const gen = (this._renderGen || 0) + 1
    this._renderGen = gen
    const { lang } = this.data
    const profile = this.draftProfile()
    // 英文界面下小样得用英文笔记：断行、字距、行高在两种语言下不是一套数
    const sample = lang === 'en' ? poster.SAMPLE_NOTE_EN : poster.SAMPLE_NOTE
    const groups = this.data.groups.map((g) => ({ id: g.id, label: g.label, items: g.items.slice() }))
    for (let gi = 0; gi < groups.length; gi++) {
      for (let ii = 0; ii < groups[gi].items.length; ii++) {
        if (this._renderGen !== gen) return
        const tpl = groups[gi].items[ii]
        try {
          const canvas = await this.getCanvas(`#tpl-${tpl.id}`)
          const ctx = canvas.getContext('2d')
          const images = {}
          if (profile.avatarPath) {
            images.avatar = await poster.loadImage(canvas, profile.avatarPath, 4000)
          }
          canvas.width = poster.W
          canvas.height = MEASURE_H
          const plan = poster.planPoster(ctx, sample, tpl.id, profile, lang)
          const h = Math.round((plan.height * THUMB_W) / poster.W)
          // 高度必须在落笔之前逐格提交给视图层：这一格显示的真是 {{item.h}}rpx，
          // 骨架里那是个 4:3 的占位数。等整轮画完再一次性 setData，画的过程中这十格
          // 都被压在占位框里竖着挤一挤——圆角跟着挤成椭圆（clipRounded 是画进位图的，
          // 位图不弯、显示弯）。一格里一次 setData 只改一个字段，代价比看到的问题小。
          const shown = plan.fellBack ? poster.templateLabel(plan.template, lang) : tpl.label
          this.setData({
            [`groups[${gi}].items[${ii}].h`]: h,
            // 跑坏退到默认那一套时，这一格的名字跟着**画出来的那张**念（N10）：
            // 念着「图文卡」而格子里是笔记卡，人会以为那套模板长这样。
            [`groups[${gi}].items[${ii}].label`]: shown,
          })
          await new Promise((r) => wx.nextTick(r))
          // 改宽高会重置画布状态，所以 scale 必须在之后设
          canvas.width = Math.round(plan.width * THUMB_SCALE)
          canvas.height = Math.round(plan.height * THUMB_SCALE)
          ctx.scale(THUMB_SCALE, THUMB_SCALE)
          poster.clipRounded(ctx, plan.width, plan.height, THUMB_R, THUMB_W)
          // 解码头像可以慢到四秒，落笔前必须再对一次号。
          // 只在循环头对不够：那一遍等完回来，新的一遍可能已经画到同一张画布上，
          // 后落笔的覆盖先落笔的——旧内容反而成了最终画面。
          if (this._renderGen !== gen) return
          poster.paintLayers(ctx, plan.layers, images)
          groups[gi].items[ii] = Object.assign({}, tpl, { h, label: shown })
        } catch (err) {
          console.error('模板小样没画出来', tpl.id, err)
          groups[gi].items[ii] = Object.assign({}, tpl, { h: Math.round(THUMB_W * 1.4) })
        }
      }
    }
    if (this._renderGen !== gen) return
    this.setData({ groups })
  },

  getCanvas(selector) {
    return new Promise((resolve, reject) => {
      wx.createSelectorQuery().in(this)
        .select(selector)
        .fields({ node: true, size: true })
        .exec((res) => {
          const canvas = res && res[0] && res[0].node
          if (canvas) resolve(canvas)
          else reject(new Error(`画布未就绪：${selector}`))
        })
    })
  },

  onUnload() {
    if (this._thumbTimer) clearTimeout(this._thumbTimer)
    // 四个槽那一块是即时落盘的，走到这里通常已经没东西可收；留着这一句是为了
    // 唯一那种漏网：复制成功、写 storage 之前抛了异常，那张谁都没用上的图。
    poster.dropUncommitted()
  },

  // 站长 10-30 一句「卡片市场……这里只是浏览功能，不需要选择」⇒ 这一屏不再有"点一格挑模板"那一下
  // （原来它叫 `onPickTemplate`：当场写 storage 再推上云，10-21 撤掉那条「保存」后靠它兜住挑的那套）。
  // 屏上既然没有任何一格亮着，点了却还在偷偷改默认模板比留着黑边更糟，所以连着撤。
  // 默认模板今天还有两个写者：换手机/重装时云端那份拉回来（`profileCloud.pull` → `writeProfile({template})`），
  // 以及新用户从没改过的本机默认；读者仍是首页"第一篇自动出那张卡"那一路（`index.js` 读 `profile.template`）。

  // ── 弹窗那一份实现的两个钩子（约定写在 utils/cardInfo.js 头上）
  // 动过四格里任何一张：重画这十格小样（头像画在卡片上），并把四格推上云（2.1 那条链，
  // 全仓只有这一页推——弹窗自己只写本机，不接这一句就是"换台手机那格是空的"）。
  _ciAfterCommit() {
    this.renderThumbs()
    profileCloud.pushSlots(poster.readSlots()).then(() => {
      // 刚传上去那几张的 fileID 只写回 storage：不接回来，下一次动任意一格都会把已有那几张
      // 整批重传一遍，而每一趟 PUT 都算一次"换下旧地址"（10-11 审计中④）。
      if (typeof this.setData === 'function') this.setData({ ciSlots: this._ciCaps(poster.readSlots()) })
    })
    return {}
  },

  // 收窗且真动过：名称/一句话已经由 onCiSave 写进本机，这里补上云那一句＋重画十格。
  _ciAfterChange() {
    const saved = poster.readProfile()
    profileCloud.pushText({
      name: (saved.name || '').trim().slice(0, 16),
      slogan: (saved.slogan || '').trim().slice(0, 24),
      // 这一屏不再挑模板 ⇒ 推的是本机存的那一套原样（没有就不带这一枚键，`pushText` 自己会跳）。
      template: saved.template,
    })
    this.renderThumbs()
  },

  ...cardInfo.handlers,
})
