// 反馈邮箱只有一个来源：「我的」那一行和「关于」那一行读同一份，
// 换地址改这一行，不会出现两页各留一个旧地址。
module.exports = { CONTACT_EMAIL: 'jacky28471258@gmail.com' }
