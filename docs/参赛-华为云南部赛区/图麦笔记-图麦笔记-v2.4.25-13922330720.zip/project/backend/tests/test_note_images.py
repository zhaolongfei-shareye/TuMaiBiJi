"""外链贴图随笔记存档这条后端链路（正本 `docs/方案-公众号贴图随笔记存档.md` 第八节那十一条）。

跑法：cd backend && .venv/bin/python -m pytest tests/test_note_images.py -q

这批尺子里最要紧的四条，都是"红的时候说的假话最贵"那种：
- **占位图反向钉**：非微信 Referer 回的是 `200 ＋ 2,090 B 那张 140×140 的 jpeg`。
  只按状态码判成败的实现会把它当正文图存进笔记，而且全绿——这一条就是为了让那种写法当场红。
- **两头同值**：服务端的预算与长边必须与 `miniprogram/utils/imageCompress.js` 逐字相等，
  并且**只改一头要红**。两处数字分家之后，"压到同一把尺子"这句承诺就不成立了。
- **一张失败不拖垮整篇**：笔记照建、摘要照出，失败只变成一个数。
- **张数上限只有一个出处**：这一路要读 `MAX_ASSETS_PER_NOTE`，出现第二个字面量 9 就红
  （与 `docs/工具/验-张数只有一个出处.js` 同一条纪律，这一份是把范围扩到新模块那半）。

全程不出网：下载与上传都换成记账的替身，域名解析一律 monkeypatch。
"""
import asyncio
import io
import logging
import os
import sys
import time
from pathlib import Path

os.environ["DATABASE_URL"] = "sqlite:////tmp/tumaibiji_pytest_note_images.db"
os.environ["JWT_SECRET_KEY"] = "pytest-only-secret-not-a-real-one"
os.environ["EXTRACT_PROVIDER"] = "none"

BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND))

import pytest  # noqa: E402
from PIL import Image, ImageDraw  # noqa: E402

from app.api.routes.notes import NoteUpdate  # noqa: E402
from app.core.config import settings  # noqa: E402
from app.core.errors import UserError  # noqa: E402
from app.db.database import Base, SessionLocal, engine  # noqa: E402
from app.models.asset import MAX_ASSETS_PER_NOTE, Asset  # noqa: E402
from app.models.note import Note  # noqa: E402
from app.models.user import User  # noqa: E402
from app.services import note_images  # noqa: E402
from app.services import scraper  # noqa: E402
from app.tasks import ingest_tasks  # noqa: E402

CF_URL = "https://gateway.test/v1/functions/image_store"
CF_KEY = "pytest-long-lived-admin-key"


@pytest.fixture()
def db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    session = SessionLocal()
    yield session
    session.close()
    Base.metadata.drop_all(bind=engine)


@pytest.fixture()
def channel(monkeypatch):
    """把"通道配好了"这一态打开。默认（现网今天的样子）是没配＝整条不做。"""
    monkeypatch.setattr(settings, "IMAGE_STORE_CF_URL", CF_URL)
    monkeypatch.setattr(settings, "IMAGE_STORE_CF_KEY", CF_KEY)
    return monkeypatch


@pytest.fixture()
def note_user(db):
    u = User(openid=f"imgs-{int(time.time() * 1000)}")
    db.add(u)
    db.commit()
    n = Note(user_id=str(u.id), title="测试篇", source_type="wechat_article",
             source_url="https://mp.weixin.qq.com/s/x")
    db.add(n)
    db.commit()
    db.refresh(n)
    return u, n


# ------------------------------------------------------------------ 替身：下载与上传

def _jpeg(width: int, height: int, quality: int = 90) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", (width, height), (200, 120, 40)).save(buf, "JPEG", quality=quality)
    return buf.getvalue()


def _png(width: int, height: int) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", (width, height), (10, 20, 30)).save(buf, "PNG")
    return buf.getvalue()


class _Resp:
    def __init__(self, status=200, headers=None, body=b"", json_body=None):
        self.status_code = status
        self.headers = headers or {}
        self.body = body
        self._json = json_body

    @property
    def is_redirect(self):
        return self.status_code in (301, 302, 303, 307, 308) and bool(self.headers.get("location"))

    def text(self):
        return self.body.decode("utf-8", "replace")

    def json(self):
        if self._json is None:
            raise ValueError("no json")
        return self._json

    async def aiter_bytes(self, chunk_size=8192):
        step = max(1, chunk_size)
        for i in range(0, len(self.body), step):
            yield self.body[i:i + step]


class _Stream:
    def __init__(self, resp):
        self._resp = resp

    async def __aenter__(self):
        return self._resp

    async def __aexit__(self, *exc):
        return False


class FakeHttp:
    """GET 回预置的那张图、POST 回一个 fileID，两头都记账。"""

    def __init__(self, routes=None, upload_json=None, upload_status=200):
        self.routes = routes or {}
        self.upload_json = upload_json or {"fileID": "cloud://env.x/images/1/20261019/abc.jpg"}
        self.upload_status = upload_status
        self.gets = []
        self.posts = []

    def stream(self, method, url, **kw):
        self.gets.append(url)
        return _Stream(self.routes.get(url, _Resp(404, body=b"nope")))

    async def post(self, url, json=None, headers=None, **kw):
        self.posts.append({"url": url, "headers": headers or {}, "json": json or {}})
        if self.upload_status >= 400:
            return _Resp(self.upload_status, body=b'{"error":"boom"}')
        return _Resp(200, json_body=self.upload_json)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        return False


def _wire(monkeypatch, fake: FakeHttp):
    # 顺手把"这一批实际挂上去了哪些头"记回替身身上（`Test六_来路那一枚` 要读的就是它）：
    # 原来这里写成 `lambda **kw: fake`，把头吞掉了——那样的替身量不出"默认那一批到底带没带 Referer"。
    fake.客户端头 = {}

    def _造(**kw):
        fake.客户端头 = dict(kw.get("headers") or {})
        return fake

    monkeypatch.setattr(note_images.httpx, "AsyncClient", _造)
    # 域名一律解析到公网；写成字面 IP 的那些回它自己（否则"第一跳公网、Location 指向元数据地址"
    # 那条绕法根本测不出来——替身把所有解析都改成公网，等于把闸门替产品关掉了）。
    import ipaddress

    def _resolve(host, *a, **kw):
        try:
            ipaddress.ip_address(host)
            ip = host
        except ValueError:
            ip = "93.184.216.34"
        return [(2, 1, 6, "", (ip, 0))]

    monkeypatch.setattr(scraper.socket, "getaddrinfo", _resolve)
    return fake


def _img(url: str, body: bytes, ctype: str = "image/jpeg") -> dict:
    return {url: _Resp(200, headers={"content-type": ctype}, body=body)}


# ------------------------------------------------------------------ 一、防盗链两种形状

class Test一_占位图与硬拒:
    def test_占位图样本自己得先成立(self):
        """10-19 02:1x 实测那条：2,090 B、JPEG、140×140。断言行为之前先断言样本是那样。"""
        sample = _jpeg(140, 140, quality=20)
        im = Image.open(io.BytesIO(sample))
        assert len(sample) <= note_images.PLACEHOLDER_MAX_BYTES, f"样本 {len(sample)} B，不是那条读数说的那种小图"
        assert (im.width, im.height) == (140, 140)

    def test_占位图必须被拒_只按状态码判的实现会在这条绿(self):
        with pytest.raises(note_images.SkipImage):
            note_images._inspect(_jpeg(140, 140, quality=20))

    def test_小字节但尺寸正常的那张不许误杀(self):
        """10-18 实测腾讯云社区有两张正文图只有 767 B／1,253 B——只按字节卡会把真图判死。"""
        tiny = _png(400, 300)
        im, long_edge = note_images._inspect(tiny)
        assert long_edge == 400 and im.format == "PNG"

    def test_小尺寸的动图不许当占位图丢掉(self):
        """10-19 本机端到端实测到的误杀：真公众号文章里一张 47×91、1,242 B、25 帧的动图。

        占位图那两条阈值只管**静**图——微信那张占位是静 JPEG（140×140／2,090 B），
        动图不可能是它。反向那半条钉的是"只管静图"而不是"动图豁免一切"：同一张去掉动画就得拦。
        """
        frames = [Image.new("RGB", (47, 91), (c * 60 % 256, c * 20 % 256, 200))
                  .convert("P", palette=Image.ADAPTIVE) for c in (1, 2, 3)]
        buf = io.BytesIO()
        frames[0].save(buf, "GIF", save_all=True, append_images=frames[1:], duration=100, loop=0)
        raw = buf.getvalue()
        probe = Image.open(io.BytesIO(raw))
        assert getattr(probe, "is_animated", False) and max(probe.size) <= note_images.PLACEHOLDER_MAX_EDGE
        assert len(raw) <= note_images.PLACEHOLDER_MAX_BYTES, f"样本 {len(raw)} B，够不到那条阈值就白测"
        assert note_images._inspect(raw)[1] == 91

        still = io.BytesIO()
        frames[0].save(still, "GIF")
        one = still.getvalue()
        assert not getattr(Image.open(io.BytesIO(one)), "is_animated", False)
        with pytest.raises(note_images.SkipImage):
            note_images._inspect(one)

    def test_解不出来的当场拒而不是落一行坏数据(self):
        with pytest.raises(note_images.SkipImage):
            note_images._inspect(b"<html>not an image at all</html>")

    def test_响应头不是图片就跳过(self, channel, monkeypatch):
        url = "https://a.test/1.jpg"
        fake = _wire(monkeypatch, FakeHttp({url: _Resp(200, {"content-type": "text/html"}, b"<html>")}))
        out = _run_archive(monkeypatch, fake, [url])
        assert out.total == 1 and not out.kept and len(out.failed) == 1
        assert len(fake.posts) == 0, "响应头就不是图，还往桶里传了一次"

    def test_默认那一批一个字的Referer都不加(self, channel, monkeypatch):
        """模块头第 3 条那条纪律的下半场。`archive` 新添的 `referer` 一格默认必须是空——
        做成全局开关会同时带坏两族：`mmbiz.qpic.cn` 带错来路回的是 **200＋2,090 B 那张 140×140 占位图**
        （状态码抓不到），`sns-webpic-qc.xhscdn.com` 带任何外来路回**硬 403**（10-19 各打三次复现）。"""
        import asyncio
        url = "https://a.test/1.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(500, 500))))
        out = asyncio.run(note_images.archive([url], "1", MAX_ASSETS_PER_NOTE))
        assert "Referer" not in fake.客户端头, fake.客户端头
        assert len(out.kept) == 1, "不加来路这一批本来就该存得下——那两族的形状不许被这一刀改坏"

    def test_默认那一批也不许换UA(self, channel, monkeypatch):
        """10-31 搜狐那一刀给 `archive` 又添了一枚 `user_agent`。同一枚纪律：默认那一批
        必须还是 `IMAGE_HEADERS` 那枚 Windows 桌面 UA——微博那族卡的是"这枚 UA 配微博的来路"，
        全局换掉等于把已经上现网的那一族推到未知里（现读：生产 UA＋微博来路三档全 200）。"""
        import asyncio
        url = "https://a.test/1.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(500, 500))))
        asyncio.run(note_images.archive([url], "1", MAX_ASSETS_PER_NOTE))
        assert fake.客户端头.get("User-Agent") == note_images.IMAGE_HEADERS["User-Agent"], fake.客户端头

    def test_点名要的那一批才带那一枚来路(self, channel, monkeypatch):
        """微博那族 10-31 现网出口读数：生产那套头（桌面 UA＋`Accept: image/*`）不带 Referer 时
        `wx*.sinaimg.cn` 整批 **403／238 B**；带 `https://m.weibo.cn/`（或 `https://weibo.com/`）时
        `orj360`／`mw2000`／`large` 三档全 **200**；带一枚外站来路（example.com）**仍 403／304 B**。
        ⇒ 这一枚只能是"这一族点名要"，不能是按域名猜、更不能全局。"""
        import asyncio
        url = "https://wx4.sinaimg.cn/mw2000/62541bfaly1iiic446fobj22cc34gnpe.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(500, 500))))
        out = asyncio.run(note_images.archive([url], "1", MAX_ASSETS_PER_NOTE,
                                             referer="https://m.weibo.cn/"))
        assert fake.客户端头.get("Referer") == "https://m.weibo.cn/", fake.客户端头
        assert len(out.kept) == 1

    def test_点名要UA的那一批只换UA不带来路(self, channel, monkeypatch):
        """搜狐那族 10-31 现网出口读数：三篇文章九张逐张打——带生产那套头 **6 张 403／3 张 200**，
        换成 `scraper._SOHU_IMAGE_UA` **九张全 200**；而带 Referer（本站、整篇地址）救不回来。
        ⇒ 这一族点名换的就是 UA，来路那一格必须仍是"不加"（加了也不解决问题，还把纪律做成两台判分机）。"""
        import asyncio
        url = "https://q8.itc.cn/q_70/images03/20261031/42287244a08644d1b7d0036c808ffe46.jpeg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(500, 500))))
        out = asyncio.run(note_images.archive([url], "1", MAX_ASSETS_PER_NOTE,
                                             user_agent=scraper._SOHU_IMAGE_UA))
        assert fake.客户端头.get("User-Agent") == scraper._SOHU_IMAGE_UA, fake.客户端头
        assert "Referer" not in fake.客户端头, fake.客户端头
        assert len(out.kept) == 1

    def test_来路只从参数来_不许在这一层按域名猜(self):
        """10-31 改口后的形状：默认那一批仍一个字都不加（`IMAGE_HEADERS` 里没有 Referer、
        `_download` 也不加），唯一的出口是 `archive` 的 `referer` 那一格；
        而且这一层不许出现"看着像哪一族就补哪一枚"的域名判断——两族防盗链方向相反
        （`mmbiz.qpic.cn` 带错来路是 200＋占位图、`xhscdn` 是硬 403），按域名猜等于把这条纪律做成一台判分机。"""
        assert not any("referer" in k.lower() for k in note_images.IMAGE_HEADERS)
        src = __import__("inspect").getsource(note_images._download).lower()
        assert "referer" not in src, "_download 里出现了 Referer，默认那一批就不再是空"
        档 = __import__("inspect").getsource(note_images.archive).lower()
        assert 档.count('"referer"') <= 1, "那一枚头只许在'参数非空才挂'那一句里出现"
        assert 档.count('"user-agent"') <= 1, "UA 也只许在'参数非空才换'那一句里出现"
        # 域名黑白名单只许在**抓取那一层**（它才知道自己落在哪一站）；这一层只按参数办事。
        # 扫 `co_consts` 不扫整段源码：docstring 里那些读数就写着 `_SOHU_IMAGE_UA`、微博那几枚域名，
        # 拿它当"代码里按域名猜"的证据会把一条好话读成假话。
        串 = [c for c in note_images.archive.__code__.co_consts
              if isinstance(c, str) and c != (note_images.archive.__doc__ or "")]
        for 域名 in ("sinaimg", "qpic", "xhscdn", "itc.cn", "sspai", "sohu"):
            assert not any(域名 in c.lower() for c in 串), \
                f"在这一层按域名补头（命中 {域名}）——上面那几条反向钉就白钉了"


# ------------------------------------------------------------------ 二、SSRF 闸门

class Test二_SSRF:
    """图地址来自外部 HTML，不是他打进那一行的，但风险一模一样。"""

    def test_字面内网地址过不了闸门(self, monkeypatch):
        with pytest.raises(UserError):
            note_images._validate("http://169.254.0.23/latest/meta-data/x.png")

    def test_IPv6未指定地址过不了闸门(self, monkeypatch):
        with pytest.raises(UserError):
            note_images._validate("http://[::]:6379/x.png")

    def test_域名解析到内网也拦(self, monkeypatch):
        monkeypatch.setattr(
            scraper.socket, "getaddrinfo",
            lambda *a, **kw: [(2, 1, 6, "", ("10.0.0.5", 0))],
        )
        with pytest.raises(UserError):
            note_images._validate("https://looks-fine.example/x.png")

    def test_跳转目标也要重新判一次(self, channel, monkeypatch):
        """只判第一次＝没判：第一跳公网、Location 指向 169.254.0.23 是最省事的绕法。"""
        hop = "https://ok.example/a.png"
        fake = _wire(monkeypatch, FakeHttp({
            hop: _Resp(302, {"location": "http://169.254.169.254/meta"}, b""),
        }))
        with pytest.raises(UserError):
            import asyncio
            asyncio.run(note_images._download(fake, hop))
        assert fake.gets == [hop], "第二跳不该已经发出去"

    def test_闸门回的句子不暴露内网(self, monkeypatch):
        with pytest.raises(UserError) as e:
            note_images._validate("http://100.64.1.2/x.png")
        assert e.value.args[0] == scraper.BLOCKED_URL_HINT


# ------------------------------------------------------------------ 三、上限与失败形状

def _run_archive(monkeypatch, fake, images, user_id="1", limit=MAX_ASSETS_PER_NOTE):
    import asyncio
    return asyncio.run(note_images.archive(images, user_id, limit))


class Test三_张数与失败:
    def test_十二张只发九次下载只登记九行(self, channel, monkeypatch, db, note_user):
        urls = [f"https://a.test/{i}.jpg" for i in range(12)]
        routes = {u: _Resp(200, {"content-type": "image/jpeg"}, _jpeg(600, 600)) for u in urls}
        fake = _wire(monkeypatch, FakeHttp(routes))
        out = _run_archive(monkeypatch, fake, urls)
        assert len(fake.gets) == MAX_ASSETS_PER_NOTE, f"发了 {len(fake.gets)} 次下载，上限是 {MAX_ASSETS_PER_NOTE}"
        assert len(out.kept) == MAX_ASSETS_PER_NOTE
        assert out.truncated == 3, "被上限砍掉的那三张要能数出来，屏上那句实话读的就是它"
        assert note_images.register(db, note_user[1], out.kept) == MAX_ASSETS_PER_NOTE

    def test_三张里一张下不动时笔记照建那一行也不许虚(self, channel, monkeypatch, db, note_user):
        good = ["https://a.test/1.jpg", "https://a.test/3.jpg"]
        routes = {u: _Resp(200, {"content-type": "image/jpeg"}, _jpeg(500, 500)) for u in good}
        routes["https://a.test/2.jpg"] = _Resp(403, {}, b"denied")
        fake = _wire(monkeypatch, FakeHttp(routes))
        out = _run_archive(monkeypatch, fake, good[:1] + ["https://a.test/2.jpg"] + good[1:])
        assert len(out.kept) == 2 and len(out.failed) == 1
        assert note_images.register(db, note_user[1], out.kept) == 2
        rows = db.query(Asset).filter(Asset.note_id == note_user[1].id).all()
        assert len(rows) == 2
        assert all(r.backup_status == "uploaded" for r in rows), "失败的压根不该落行，落了就是云上没东西却占配额"

    def test_通道没配时一张都不下载_代码可以先上通道后配(self, monkeypatch):
        import asyncio
        monkeypatch.setattr(settings, "IMAGE_STORE_CF_URL", "")
        monkeypatch.setattr(settings, "IMAGE_STORE_CF_KEY", CF_KEY)
        fake = _wire(monkeypatch, FakeHttp({}))
        assert note_images.channel_ready() is False
        out = asyncio.run(note_images.archive(["https://a.test/1.jpg"], "1", MAX_ASSETS_PER_NOTE))
        assert fake.gets == [] and fake.posts == []
        assert out.total == 1 and not out.kept and not out.failed, "没开工不该报成「九张里一张都没存上」"

    def test_占位图那一张进failed而不是kept(self, channel, monkeypatch):
        url = "https://a.test/ph.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(140, 140, quality=20))))
        out = _run_archive(monkeypatch, fake, [url])
        assert not out.kept and out.failed == [url]
        assert fake.posts == [], "拒了就不该还往桶里传"

    def test_上传那一趟回错误时这张算没存上(self, channel, monkeypatch):
        url = "https://a.test/1.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(600, 600)), upload_status=500))
        out = _run_archive(monkeypatch, fake, [url])
        assert not out.kept and len(out.failed) == 1

    def test_没拿到像样fileID时不许落一行指向空的账(self, channel, monkeypatch):
        url = "https://a.test/1.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(600, 600)), upload_json={"fileID": "cloud://"}))
        out = _run_archive(monkeypatch, fake, [url])
        assert not out.kept and len(out.failed) == 1


# ------------------------------------------------------------------ 四、格式、尺寸、压缩

class Test四_不许照URL猜:
    def test_地址尾巴写png回来的却是jpeg时记的必须是jpeg(self, channel, monkeypatch):
        """10-18 实测：`/640?wx_fmt=png` 回的是 JPEG、1080 宽。照着 URL 记就把每张都记错了。"""
        url = "https://mmbiz.qpic.cn/x/640?wx_fmt=png"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(1080, 1440), ctype="image/jpeg")))
        out = _run_archive(monkeypatch, fake, [url])
        assert out.kept[0].mime == "image/jpeg"
        assert (out.kept[0].width, out.kept[0].height) == (1080, 1440)

    def test_长边超过1920的那张被缩到1920(self, channel, monkeypatch):
        url = "https://a.test/big.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(4000, 3000))))
        out = _run_archive(monkeypatch, fake, [url])
        assert max(out.kept[0].width, out.kept[0].height) == note_images.MAX_LONG_EDGE

    def test_压完确实进了预算(self, channel, monkeypatch):
        url = "https://a.test/shot.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(1200, 1600, quality=98))))
        out = _run_archive(monkeypatch, fake, [url])
        assert out.kept[0].size <= note_images.BUDGET_BYTES
        assert out.kept[0].over_budget is False

    def test_动图原样存不压(self, channel, monkeypatch):
        """⚠ 这一条是我定的、站长没拍过（他只说「压缩图片」）：压掉就成静帧。要反过来只需一句「动图也压」。

        样本故意做成 800×600 的大动图：60×60 那种会先被占位图那一条拦掉，测的就不是这一条了。
        """
        buf = io.BytesIO()
        frames = [Image.new("RGB", (800, 600), (c * 40 % 256, c * 90 % 256, c * 150 % 256))
                  .convert("P", palette=Image.ADAPTIVE) for c in (1, 2, 3)]
        frames[0].save(buf, "GIF", save_all=True, append_images=frames[1:], duration=100, loop=0)
        raw = buf.getvalue()
        assert max(Image.open(io.BytesIO(raw)).size) > note_images.PLACEHOLDER_MAX_EDGE
        url = "https://mmbiz.qpic.cn/anim.gif"
        fake = _wire(monkeypatch, FakeHttp(_img(url, raw, ctype="image/gif")))
        out = _run_archive(monkeypatch, fake, [url])
        assert out.kept[0].mime == "image/gif"
        import base64
        assert base64.b64decode(fake.posts[0]["json"]["data"]) == raw, "动图被重编码了"

    def test_动图超预算那一格照字节报不硬写False(self, channel, monkeypatch):
        """客户端那把尺子的 `overBudget` 是纯字节比较（不问格式），动图这一支也一样。

        10-19 本机端到端实测：真公众号文章里一张 1078×233 的动图原样存就是 1,018,668 B，
        原来硬写 False 等于账上出现"两倍预算却记成没超"。阈值这里压到 10 B 来钉这一条。
        """
        buf = io.BytesIO()
        frames = [Image.new("RGB", (300, 300), (c * 60 % 256, c * 20 % 256, 200))
                  .convert("P", palette=Image.ADAPTIVE) for c in (1, 2)]
        frames[0].save(buf, "GIF", save_all=True, append_images=frames[1:], duration=100, loop=0)
        raw = buf.getvalue()
        url = "https://mmbiz.qpic.cn/anim2.gif"
        fake = _wire(monkeypatch, FakeHttp(_img(url, raw, ctype="image/gif")))
        assert max(Image.open(io.BytesIO(raw)).size) > note_images.PLACEHOLDER_MAX_EDGE
        assert len(raw) <= note_images.BUDGET_BYTES
        assert _run_archive(monkeypatch, fake, [url]).kept[0].over_budget is False
        monkeypatch.setattr(note_images, "BUDGET_BYTES", 10)
        assert _run_archive(monkeypatch, fake, [url]).kept[0].over_budget is True

    def test_超过网关上限的那张算没存上而不是把整趟撑爆(self, channel, monkeypatch):
        url = "https://a.test/huge.jpg"
        body = _jpeg(3000, 3000, quality=100)
        fake = _wire(monkeypatch, FakeHttp(_img(url, body)))
        monkeypatch.setattr(note_images, "MAX_UPLOAD_BYTES", 1024)
        out = _run_archive(monkeypatch, fake, [url])
        assert not out.kept and out.failed == [url]

    def test_动WebP与APNG也原样存不被压成静帧(self, channel, monkeypatch):
        """10-19 审查抓到的"名字比实现大"：注释写"动图原样存"，那一判却写死 `fmt == "GIF"`。

        这两族都是 `Accept` 里明说要收的格式，落到静图那一支就是**动画被吃掉**——
        用户看到的是一张会动的图存下来不会动了，比"没存上"更难解释。
        """
        import base64

        webp_frames = [Image.new("RGB", (300, 300), (c * 60 % 256, 40, 200))
                       .convert("P", palette=Image.ADAPTIVE) for c in (1, 2)]
        buf = io.BytesIO()
        webp_frames[0].save(buf, "WEBP", save_all=True, append_images=webp_frames[1:],
                            duration=100, loop=0)
        webp = buf.getvalue()
        png_frames = [Image.new("RGBA", (300, 300), (c * 50 % 256, 60, 180, 255)) for c in (1, 2)]
        buf2 = io.BytesIO()
        png_frames[0].save(buf2, "PNG", save_all=True, append_images=png_frames[1:],
                           duration=100, loop=0)
        apng = buf2.getvalue()

        urls = ["https://a.test/anim.webp", "https://a.test/anim.png"]
        routes = {
            urls[0]: _img(urls[0], webp, ctype="image/webp"),
            urls[1]: _img(urls[1], apng, ctype="image/png"),
        }
        flat = {k: v for d in routes.values() for k, v in d.items()}
        fake = _wire(monkeypatch, FakeHttp(flat))
        out = _run_archive(monkeypatch, fake, urls)
        assert [s.mime for s in out.kept] == ["image/webp", "image/apng"], out.kept
        sent = [base64.b64decode(p["json"]["data"]) for p in fake.posts]
        assert sent == [webp, apng], "动图被重编码成静帧了"
        assert [p["json"]["cloud_path"].split(".")[-1] for p in fake.posts] == ["webp", "png"]

    def test_透明底那张压完垫白不糊成黑块(self, channel, monkeypatch):
        """Pillow 的 `convert("RGB")` 是丢 alpha 不合成：原图透明处底层是黑，存出来就是一块黑。

        本机实测同一张 600×400、透明区底层分别是黑／白，压完四角读回 `(1,1,1)` 与 `(241,241,241)`
        ——同一族图出来是黑还是白全看原作者 PNG 里那层没人看的像素。配图落在白底卡上，所以垫白。
        """
        def shot(bg):
            im = Image.new("RGBA", (600, 400), (bg, bg, bg, 0))
            d = ImageDraw.Draw(im)
            d.rectangle([80, 80, 520, 320], fill=(20, 22, 26, 255))
            buf = io.BytesIO()
            im.save(buf, "PNG")
            return buf.getvalue()

        for name, bg in (("底层黑", 0), ("底层白", 240)):
            url = f"https://a.test/t-{bg}.png"
            fake = _wire(monkeypatch, FakeHttp(_img(url, shot(bg), ctype="image/png")))
            out = _run_archive(monkeypatch, fake, [url])
            import base64
            body = base64.b64decode(fake.posts[0]["json"]["data"])
            corner = Image.open(io.BytesIO(body)).convert("RGB").getpixel((5, 5))
            assert min(corner) > 240, f"{name}那一张四角读回 {corner}，alpha 没垫白"
            assert out.kept[0].mime == "image/jpeg"


# ------------------------------------------------------------------ 五、两头同值

JS = (BACKEND.parent / "miniprogram" / "utils" / "imageCompress.js").read_text(encoding="utf-8")


def _js_number(name: str) -> int:
    """读 `imageCompress.js` 里那一行常量。只认 `1920` 与 `500 * 1024` 两种写法，不 eval。"""
    import re
    m = re.search(rf"const {name} = (\d+)(?: \* (\d+))?\s*\n", JS)
    assert m, f"imageCompress.js 里读不到 {name} 那一行（那头改了写法，这里要跟着改）"
    return int(m.group(1)) * int(m.group(2) or 1)


def _js_ladder() -> list:
    import re
    m = re.search(r"const QUALITY_LADDER = \[([0-9., ]+)\]", JS)
    assert m, "imageCompress.js 里读不到 QUALITY_LADDER 那一行"
    return [float(x) for x in m.group(1).split(",")]


class Test五_两头同一把尺子:
    def test_长边与预算与服务端逐字相等(self):
        assert note_images.MAX_LONG_EDGE == _js_number("MAX_LONG_EDGE")
        assert note_images.BUDGET_BYTES == _js_number("BUDGET_BYTES")
        assert list(note_images.QUALITY_LADDER) == _js_ladder()

    def test_反向钉只改一头立刻红(self, monkeypatch):
        """不立这一条，将来抬预算只会抬出一套两真相：客户端 800KB、服务端 500KB，谁都没错但图不一样。"""
        monkeypatch.setattr(note_images, "BUDGET_BYTES", 800 * 1024)
        with pytest.raises(AssertionError):
            assert note_images.BUDGET_BYTES == _js_number("BUDGET_BYTES")

    def test_张数上限不许在这里出现第二个字面量(self):
        """`docs/工具/验-张数只有一个出处.js` 同一条纪律，只是把扫的范围扩到新模块。"""
        src = Path(note_images.__file__).read_text(encoding="utf-8")
        body = src.split('"""', 2)[2]  # 模块头那大段话里会正引用"最多 9 张"那句原话，不算写死的数
        assert "MAX_ASSETS_PER_NOTE" in Path(ingest_tasks.__file__).read_text(encoding="utf-8")
        for bad in ("= 9", "limit=9", ", 9)", "range(9)"):
            assert bad not in body, f"新模块里出现了第二个上限写法 {bad!r}"

    def test_单文件字节上限全仓只有模型那一处定义(self):
        """10-19 审查里抓到的一条：新模块抄了第二份 `20 * 1024 * 1024`，注释却写着"不重打一遍"。

        两处各写一份走样时的症状不是报错，是"接口收得下、下载这一头先判超限丢掉"——看不见的那半最难查。
        """
        import app.api.routes.assets as assets_route
        for mod in (note_images, assets_route):
            src = Path(mod.__file__).read_text(encoding="utf-8")
            assert "20 * 1024 * 1024" not in src, f"{mod.__name__} 里又抄了一份 20MB"
        assert note_images.MAX_FILE_BYTES == assets_route.MAX_FILE_BYTES \
            == __import__("app.models.asset", fromlist=["MAX_FILE_BYTES"]).MAX_FILE_BYTES

    def test_那条上传超时的配置必须真被读一次(self):
        """配了一行却没人读的开关比没有这行更坏：下一次它静默变成"说不通的那半"。"""
        src = Path(note_images.__file__).read_text(encoding="utf-8")
        assert "IMAGE_STORE_CF_TIMEOUT" in src.split("async def _upload", 1)[1].split("async def archive")[0], \
            "IMAGE_STORE_CF_TIMEOUT 没在 _upload 里被读——它是一行假配置"


# ------------------------------------------------------------------ 六、来源那三件

WX_HTML = """
<html><body>
<h1 class="rich_media_title">班车全攻略</h1>
<div id="js_name">ZJU攻城狮</div>
<div class="rich_media_content" id="js_content">
  <img data-src="//mmbiz.qpic.cn/a.png" src="data:image/png;base64,AAA">
  <img data-src="https://mmbiz.qpic.cn/b.png">
  <img data-src="https://mmbiz.qpic.cn/a.png">
  <p>正文在这里</p>
</div>
</body></html>
"""

XHS_HTML = """
<html><head><meta property="og:title" content="芭蕾第二集"></head><body>
<script>window.__SSR__=true</script>
<script>window.__INITIAL_STATE__={"note":{"noteDetailMap":{"N1":{"note":{
 "title":"芭蕾第二集","desc":"家长们看看吧",
 "user":{"nickname":"护护","avatar":undefined},
 "imageList":[
  {"urlPre":"http://s.test/1-prev.jpg","urlDefault":"http://s.test/1.jpg","width":1247,"height":1667},
  {"urlDefault":"http://s.test/2.jpg","width":1273,"height":1662},
  {"urlDefault":"http://s.test/2.jpg","width":1273,"height":1662}
 ]}}}},"feed":undefined}</script>
<img src="https://fe-static.xhscdn.com/ui-icon.png">
</body></html>
"""


WX_ALBUM_HTML = """
<html><head>
<meta name="description" content="周慧敏是 1990 年代红遍亚洲的玉女掌门人。" />
</head><body>
<h1 class="rich_media_title">90年港圈玉女女神</h1>
<div class="rich_media_content" id="js_content">知道了 微信扫一扫 使用小程序 取消 允许 赞 在看 分享 留言 收藏</div>
<img src="https://res.wx.qq.com/ui-icon.png">
<script>
window.cgiDataNew = {
  picture_page_info_list: [
    { cdn_url: 'https://mmbiz.qpic.cn/mmbiz_jpg/A/0?wx_fmt=jpeg',
      width: '585' * 1, height: '780' * 1,
      live_photo: { format_info: [ { cdn_url: 'https://mmbiz.qpic.cn/inside-live/1' } ] },
      pic_window_product: { title: '' } },
    { cdn_url: 'https://mmbiz.qpic.cn/sz_mmbiz_jpg/B/0?wx_fmt=jpeg',
      width: '404' * 1, height: '540' * 1 },
    { cdn_url: 'https://mmbiz.qpic.cn/mmbiz_jpg/A/0?wx_fmt=jpeg',
      width: '585' * 1, height: '780' * 1 }
  ],
  nick_name: '悦悦的日常琐碎',
  user_name: 'gh_41b550ee1638',
};
window.picture_page_info_list = ((window.cgiDataNew && window.cgiDataNew.picture_page_info_list) || []).slice(0, 20);
</script>
</body></html>
"""


class Test六_来源:
    def test_公众号那一篇取到作者名与正文图(self):
        parsed = scraper._parse_wechat_article(WX_HTML, "https://mp.weixin.qq.com/s/x", "wechat_article")
        assert parsed["author"] == "ZJU攻城狮"
        assert parsed["images"] == ["https://mmbiz.qpic.cn/a.png", "https://mmbiz.qpic.cn/b.png"], \
            "地址要补成绝对、按文档顺序去重，而且只读 data-src（实测一条 src 都没有）"

    def test_小红书那一篇四格全从那段JSON里取(self):
        extra = scraper._xiaohongshu_extras(XHS_HTML)
        assert extra["images"] == ["http://s.test/1.jpg", "http://s.test/2.jpg"], "取 urlDefault，不是 urlPre"
        assert extra["author"] == "护护"
        # 10-19 现读那篇：DOM 那一份读出来是页面皮（`创作中心／© 2014-2026／行吟信息科技／地址／电话`），
        # 笔记真正的正文只在 `note.desc`。所以标题与正文这两格也必须出自 JSON。
        assert extra["title"] == "芭蕾第二集"
        assert extra["content"] == "家长们看看吧"

    def test_JSON里那一格是空的就不覆盖DOM(self):
        """有的笔记没标题、跳到用户页／合集页时整段 note 都没有——那两格不许被写成空串。"""
        empty = XHS_HTML.replace('"title":"芭蕾第二集","desc":"家长们看看吧"', '"title":"","desc":""')
        extra = scraper._xiaohongshu_extras(empty)
        assert "title" not in extra and "content" not in extra, "空串覆盖上去就是把已有的那一格抹掉"
        assert extra["images"] and extra["author"] == "护护"

    def test_那段JSON解不开时只是没有图(self):
        assert scraper._xiaohongshu_extras("<script>window.__INITIAL_STATE__={坏掉的") == {}

    def test_相册型那一帖的图在JS里不在DOM(self):
        """10-19 他甩那条真链接逼出来的第二种形状：整页 `<img` 只有 UI 图标，图在 `picture_page_info_list[].cdn_url`。"""
        urls = scraper._wechat_album_images(WX_ALBUM_HTML)
        assert urls == ["https://mmbiz.qpic.cn/mmbiz_jpg/A/0?wx_fmt=jpeg",
                        "https://mmbiz.qpic.cn/sz_mmbiz_jpg/B/0?wx_fmt=jpeg"], \
            "按顺序、重复的并成一条，而且**每张只取顶层那一条 cdn_url**——`live_photo` 里那条嵌套的不算第二张"

    def test_相册型那一帖四格都补齐(self):
        parsed = scraper._parse_wechat_article(
            WX_ALBUM_HTML, "https://mp.weixin.qq.com/s/album", "wechat_article")
        assert len(parsed["images"]) == 2
        assert parsed["author"] == "悦悦的日常琐碎", "这种页面没有 `#js_name`，名字在 JS 的 `nick_name`"
        assert parsed["content"].startswith("周慧敏"), \
            "DOM 那一份是页面皮（知道了／微信扫一扫／允许／赞／在看），拿它去提炼就是屏上那五条废话要点"
        assert parsed["source_type"] == "wechat_article"

    def test_相册型那一格括号不配对时退回原行为(self):
        broken = WX_ALBUM_HTML.replace("pic_window_product: { title: '' } },", "pic_window_product: { title: '' },")
        assert scraper._wechat_album_images(broken) == []
        parsed = scraper._parse_wechat_article(broken, "https://mp.weixin.qq.com/s/album", "wechat_article")
        assert parsed["images"] == [], "解不出就不许硬凑一张，也不许把页面皮当正文换成别的说法"

    def test_图文型那一篇一行行为没变(self):
        """反向钉：新加的那一路只在"`#js_content` 里一张图都没有"时才走，普通图文型不许被它带偏。"""
        parsed = scraper._parse_wechat_article(WX_HTML, "https://mp.weixin.qq.com/s/x", "wechat_article")
        assert parsed["content"] == "正文在这里" and parsed["author"] == "ZJU攻城狮"
        assert len(parsed["images"]) == 2

    def test_接线那一处_小红书走JSON那一份而不是页面皮(self, monkeypatch):
        """只测 `parsed.update(_xiaohongshu_extras(...))` 这一行：撤掉它，屏上的正文就回成页面皮。"""
        html = XHS_HTML.replace('<meta property="og:title" content="芭蕾第二集">',
                                '<meta property="og:title" content="芭蕾第二集 - 小红书">') \
                        .replace('<img src="https://fe-static.xhscdn.com/ui-icon.png">',
                                 '<div>创作中心 业务合作 行吟信息科技（上海）有限公司</div>')

        class _Resp:
            status_code = 200
            is_redirect = False
            encoding = "utf-8"
            headers: dict = {}

            async def aiter_bytes(self, chunk_size=8192):
                yield html.encode("utf-8")

        class _Stream:
            async def __aenter__(self):
                return _Resp()

            async def __aexit__(self, *a):
                return False

        class _Client:
            def __init__(self, *a, **k):
                pass

            async def __aenter__(self):
                return self

            async def __aexit__(self, *a):
                return False

            def stream(self, method, url):
                return _Stream()

        monkeypatch.setattr(scraper, "_validate_url", lambda u: None)
        monkeypatch.setattr(scraper.httpx, "AsyncClient", _Client)
        parsed = asyncio.run(
            scraper._fetch_and_parse("https://www.xiaohongshu.com/discovery/item/6ad40f01000000002203c359"))
        assert parsed["content"] == "家长们看看吧", "这一族的正文必须出自 note.desc，不是 DOM 那一份页面皮"
        assert parsed["title"] == "芭蕾第二集", "标题也一样：og:title 那一份带着「 - 小红书」这种站点后缀"
        assert parsed["source_type"] == "web_article", "改的是取法，不是那一枚配额用得到的来源类型"

    def test_快照键名与转存那一路逐字同名(self):
        parsed = scraper._parse_wechat_article(WX_HTML, "https://mp.weixin.qq.com/s/x", "wechat_article")
        snap = ingest_tasks._source_snapshot(parsed, "https://mp.weixin.qq.com/s/x")
        assert snap["author_name"] == "ZJU攻城狮"
        assert snap["title_at_import"] == "班车全攻略"
        assert "source_url" in snap and "imported_at" in snap
        assert not ({"share_token", "source_note_id", "author_user_id"} & set(snap)), \
            "没有对应物的三键不该塞空串占位——读的那一头一有空值就画出一种空名字"

    def test_取不到作者名就整份不写(self):
        assert ingest_tasks._source_snapshot({"author": "", "title": "T"}, "https://x.test/a") is None

    def test_来源类型不许被改成转存那一档(self):
        """配额把 `share_import` 单独排出去了（`quota._is_his_first_note`、`credit_import`），改了会把两笔账搞混。"""
        parsed = scraper._parse_wechat_article(WX_HTML, "https://mp.weixin.qq.com/s/x", "wechat_article")
        assert parsed["source_type"] == "wechat_article"

    def test_编辑接口碰不到imported_from(self, db, note_user):
        """复用 `tests/test_share_snapshot.py` 那条的写法，外链这一路也钉一次。"""
        _, n = note_user
        n.imported_from = {"author_name": "原来那个"}
        db.commit()
        assert "imported_from" not in NoteUpdate.model_fields, "它一旦进了编辑模型，这条来源就改得掉了"


# ------------------------------------------------------------------ 七、任务那一段

class Test七_任务回体:
    def _scraped(self, images=None, author="ZJU攻城狮"):
        return {"content": "正文有的", "title": "T", "source_type": "wechat_article",
                "status_code": 200, "images": images or [], "author": author}

    def _run(self, db, statuses, monkeypatch, scraped, archive=None):
        user, _ = _make_user(db)

        async def ok(url):
            return scraped

        async def know(text, fallback_title=None, translate=None):
            return {"title": "标题", "summary": "摘要", "key_points": [], "tags": [], "degraded": False}

        monkeypatch.setattr(ingest_tasks, "scrape_url", ok)
        monkeypatch.setattr(ingest_tasks, "extract_knowledge", know)
        monkeypatch.setattr(ingest_tasks, "_blocked", lambda url: False)
        monkeypatch.setattr(ingest_tasks, "set_task_status", lambda tid, st, res=None: statuses.append((tid, st, res)))
        if archive is not None:
            monkeypatch.setattr(note_images, "archive", archive)
        monkeypatch.setattr(note_images.settings, "IMAGE_STORE_CF_URL", CF_URL)
        monkeypatch.setattr(note_images.settings, "IMAGE_STORE_CF_KEY", CF_KEY)
        ingest_tasks.process_url_task("t1", str(user.id), "https://mp.weixin.qq.com/s/x", user.generation)
        return db.query(Note).order_by(Note.id.desc()).first(), statuses

    def test_存图成功时回体带那四个数(self, db, monkeypatch):
        statuses = []
        urls = [f"https://a.test/{i}.jpg" for i in range(12)]

        async def fake_archive(images, user_id, limit, on_ready=None, *, openid, referer="", user_agent=""):
            kept = [note_images.Prepared(f"cloud://e.x/{i}", "image/jpeg", 1000, 10, 10, False, u)
                    for i, u in enumerate(images[:limit])]
            for s in kept:
                if on_ready:
                    on_ready(s)
            return note_images.ArchiveResult(kept=kept, failed=[], total=len(images))

        note, statuses = self._run(db, statuses, monkeypatch, self._scraped(urls), fake_archive)
        payload = statuses[-1][2]
        assert (payload["images_total"], payload["images_kept"], payload["images_failed"],
                payload["images_truncated"]) == (12, MAX_ASSETS_PER_NOTE, 0, 12 - MAX_ASSETS_PER_NOTE)
        assert note.imported_from["author_name"] == "ZJU攻城狮"
        assert note.imported_from["images_total"] == 12

    def test_屏上那句数的张数是真存下而不是新写了几行(self, db, monkeypatch):
        """RQ 重跑同一个 job 时 `register()` 按 object_key 幂等跳过（新写 0 行），
        但图确实在桶里、界面也列得出来。拿"新写几行"当 k 就是对着一堆看得见的图说"留下了 0 张"。"""
        statuses = []
        urls = [f"https://a.test/{i}.jpg" for i in range(3)]

        async def fake_archive(images, user_id, limit, on_ready=None, *, openid, referer="", user_agent=""):
            kept = [note_images.Prepared(f"cloud://e.x/{i}", "image/jpeg", 1000, 10, 10, False, u)
                    for i, u in enumerate(images)]
            for s_ in kept:
                if on_ready:
                    on_ready(s_)
            return note_images.ArchiveResult(kept=kept, failed=[], total=len(images))

        monkeypatch.setattr(note_images, "register", lambda db_, note_, kept: 0)
        note, statuses = self._run(db, statuses, monkeypatch, self._scraped(urls), fake_archive)
        payload = statuses[-1][2]
        assert payload["images_kept"] == 3, "计数把幂等跳过误读成一张都没存下"
        assert note.imported_from["images_kept"] == 3

    def test_存图整段炸了这次转存不算失败(self, db, monkeypatch):
        """笔记已经落库、摘要已经出来——"存不下"不许变成"这次抓取失败"。"""
        statuses = []

        async def explode(images, user_id, limit, on_ready=None):
            raise RuntimeError("网关挂了")

        note, statuses = self._run(db, statuses, monkeypatch,
                                   self._scraped(["https://a.test/1.jpg"]), explode)
        assert note is not None and statuses[-1][1] == "completed"
        assert "images_total" not in statuses[-1][2], "整段没做成时不该报数，那会被读成「一张都没存上」"
        assert db.query(Asset).count() == 0

    def test_没有图的篇子回体里一个图相关的键都不多(self, db, monkeypatch):
        statuses = []
        _, statuses = self._run(db, statuses, monkeypatch, self._scraped([]))
        assert not [k for k in statuses[-1][2] if k.startswith("images_")]

    def test_登记每一行的file_size都有值且状态只有已上传(self, db, monkeypatch):
        """第八节第 9 条：`uploaded + failed == total` 那条不变量，加上"体积不知道"那格不该由这条路造出来。"""
        statuses = []
        urls = ["https://a.test/1.jpg", "https://a.test/2.jpg"]

        async def fake_archive(images, user_id, limit, on_ready=None, *, openid, referer="", user_agent=""):
            kept = [note_images.Prepared(f"cloud://e.x/{i}", "image/jpeg", 2048 + i, 40, 30, False, u)
                    for i, u in enumerate(images)]
            for s_ in kept:
                if on_ready:
                    on_ready(s_)
            return note_images.ArchiveResult(kept=kept, failed=[], total=len(images))

        note, _ = self._run(db, statuses, monkeypatch, self._scraped(urls), fake_archive)
        rows = db.query(Asset).filter(Asset.note_id == note.id).all()
        assert len(rows) == 2
        assert all(r.file_size and r.width == 40 and r.height == 30 for r in rows)
        assert all(r.backup_status == "uploaded" for r in rows)

    def test_登记崩在第二张时第一张已经有账且不再往下传(self, db, monkeypatch):
        """10-19 审查那条孤儿：对象已经进桶、台账却排在整批之后一次性写。

        改成"传成一张、当场落一行"之后，崩在第二张时第一张已经有行；且登记炸了不再往下传
        （同一趟里第一张能写、第二张写不进，第三张照样写不进——继续传只会把孤儿堆到九张）。
        """
        statuses = []
        urls = [f"https://a.test/{i}.jpg" for i in range(3)]
        handed = []

        async def fake_archive(images, user_id, limit, on_ready=None, *, openid, referer="", user_agent=""):
            for i, u in enumerate(images):
                handed.append(u)
                on_ready(note_images.Prepared(
                    f"cloud://e.x/{i}", "image/jpeg", 1000, 10, 10, False, u))
            return note_images.ArchiveResult(kept=[], failed=[], total=len(images))

        real = note_images.register
        calls = {"n": 0}

        def flaky(db_, note_, kept):
            calls["n"] += 1
            if calls["n"] == 2:
                raise RuntimeError("数据库写不进去")
            return real(db_, note_, kept)

        monkeypatch.setattr(note_images, "register", flaky)
        note, statuses = self._run(db, statuses, monkeypatch, self._scraped(urls), fake_archive)
        assert note is not None and statuses[-1][1] == "completed", "存图炸了不许把这次转存判成失败"
        assert len(handed) == 2, f"登记已经炸了还继续传：{len(handed)} 张"
        rows = db.query(Asset).filter(Asset.note_id == note.id).all()
        assert len(rows) == 1, f"崩之前那一张的账必须留下，现读 {len(rows)} 行"
        assert "images_total" not in statuses[-1][2], "整段没做成时报数会被读成「一张都没存上」"


def _make_user(db):
    u = User(openid=f"task-{int(time.time() * 1000000) % 10**9}")
    db.add(u)
    db.commit()
    db.refresh(u)
    return u, None


# ------------------------------------------------------------------ 八、图上的字（内容安全）
# 站长 10-21「任何图文都要」⇒ 外链贴图这条链（后端本来就握着字节）在进桶之前读一遍字送 msgSecCheck。
# 这一节把三条口径钉住：① 判违规的那一张**不许进桶**；② 四种"检不了"一律放行（开关关着／没有 openid／
# OCR 自己抛了／微信那边没检成）——把抖动变成"存不下图"是现网最坏的误伤；③ 认不出字不送检（按次计配额）。
# 反向钉的一条是日志形状：拦下的那张不许被写成"站点下不动"，否则以后没法归因。

_RISKY = "线上赌场 六合彩 特码"   # 文字接口实测 risky label=20006（PRD §8.33），拿它当已知违规样本


def _sec(monkeypatch, enabled=True):
    monkeypatch.setattr(settings, "SEC_CHECK_ENABLED", enabled)


def _stub_ocr(monkeypatch, text=_RISKY, raises=None):
    seen: list = []

    async def _fake(data):
        seen.append(data)
        if raises is not None:
            raise raises
        return text

    monkeypatch.setattr(note_images, "ocr_image", _fake)
    return seen


def _stub_check(monkeypatch, verdict="risky"):
    seen: list = []

    def _fake(openid, content):
        seen.append((openid, content))
        return verdict

    monkeypatch.setattr(note_images, "check_text", _fake)
    return seen


def _run_sec_archive(monkeypatch, fake, urls, openid="o" * 28):
    return asyncio.run(note_images.archive(urls, "1", MAX_ASSETS_PER_NOTE, openid=openid))


class Test八_图上的字:
    def test_图上写着违规字时这一张不进桶(self, channel, monkeypatch):
        url = "https://a.test/bad.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(600, 600))))
        _sec(monkeypatch)
        _stub_ocr(monkeypatch)
        checks = _stub_check(monkeypatch, "risky")
        out = _run_sec_archive(monkeypatch, fake, [url])
        assert not out.kept and out.failed == [url]
        assert len(checks) == 1 and checks[0][1] == _RISKY
        assert fake.posts == [], "拦下就不该往桶里传：传了就是公开页上摊着一张没人认的图"

    def test_待人工复核那一档同样挡(self, channel, monkeypatch):
        url = "https://a.test/maybe.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(600, 600))))
        _sec(monkeypatch)
        _stub_ocr(monkeypatch)
        _stub_check(monkeypatch, "review")
        out = _run_sec_archive(monkeypatch, fake, [url])
        assert not out.kept and out.failed == [url] and fake.posts == []

    def test_判成正常时照常进桶(self, channel, monkeypatch):
        url = "https://a.test/ok.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(600, 600))))
        _sec(monkeypatch)
        _stub_ocr(monkeypatch)
        _stub_check(monkeypatch, "pass")
        out = _run_sec_archive(monkeypatch, fake, [url])
        assert len(out.kept) == 1 and len(fake.posts) == 1

    def test_认不出字时一次都不送检(self, channel, monkeypatch):
        """msgSecCheck 按次计配额：一张纯风景图没有可检的东西，白打一趟就是白烧额度。"""
        url = "https://a.test/plain.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(600, 600))))
        _sec(monkeypatch)
        _stub_ocr(monkeypatch, text="   \n ")
        checks = _stub_check(monkeypatch)
        out = _run_sec_archive(monkeypatch, fake, [url])
        assert checks == [] and len(out.kept) == 1

    def test_开关关着时连OCR都不跑(self, channel, monkeypatch):
        """整套用例默认 SEC_CHECK_ENABLED=false（conftest 显式关的，为的是不出网）——
        这一条证的是"关了就连识字这一趟都省了"，而不是"照跑只是不看结果"。"""
        url = "https://a.test/1.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(600, 600))))
        _sec(monkeypatch, enabled=False)
        ocr_seen = _stub_ocr(monkeypatch)
        checks = _stub_check(monkeypatch)
        out = _run_sec_archive(monkeypatch, fake, [url])
        assert ocr_seen == [] and checks == [] and len(out.kept) == 1

    def test_没有openid时放行并留下一句实话(self, channel, monkeypatch, caplog):
        """openid 是 msgSecCheck v2 的必填项，拿不到就只能算"没检成"。
        但必须留一行 WARNING，否则「检了」与「根本没检」在日志里长得一模一样。"""
        url = "https://a.test/1.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(600, 600))))
        _sec(monkeypatch)
        ocr_seen = _stub_ocr(monkeypatch)
        checks = _stub_check(monkeypatch)
        with caplog.at_level(logging.WARNING, logger="app.services.note_images"):
            out = _run_sec_archive(monkeypatch, fake, [url], openid=None)
        assert len(out.kept) == 1, "缺 openid 是我们的问题，不该让一张好图存不下"
        assert ocr_seen == [] and checks == []
        assert any("openid" in r.getMessage() for r in caplog.records), "关掉这一趟不许不留痕"

    def test_OCR自己抛了不许把好图判死(self, channel, monkeypatch):
        """libGL／内存／模型这类基础设施故障走"没检成"，不走"这张图违规"。"""
        url = "https://a.test/1.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(600, 600))))
        _sec(monkeypatch)
        _stub_ocr(monkeypatch, raises=UserError("图片识别暂不可用，请稍后重试"))
        checks = _stub_check(monkeypatch)
        out = _run_sec_archive(monkeypatch, fake, [url])
        assert len(out.kept) == 1 and checks == []

    def test_微信没检成时这张照常存进去(self, channel, monkeypatch, caplog):
        url = "https://a.test/1.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(600, 600))))
        _sec(monkeypatch)
        _stub_ocr(monkeypatch)
        _stub_check(monkeypatch, "unavailable")
        with caplog.at_level(logging.ERROR, logger="app.services.note_images"):
            out = _run_sec_archive(monkeypatch, fake, [url])
        assert len(out.kept) == 1, "与文字那条同口径：unavailable 是「这次没检成」，不是「这图有问题」"
        assert any("没检成" in r.getMessage() for r in caplog.records)

    def test_送检的就是真进桶那一份字节(self, channel, monkeypatch):
        """认字的对象必须是**要存进公开页的那一张**，不是下载下来的原件：
        原件可能比它大一倍，压完才是用户实际会看到的那份像素。"""
        import base64
        url = "https://a.test/big.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(3000, 2000, quality=95))))
        _sec(monkeypatch)
        ocr_seen = _stub_ocr(monkeypatch)
        _stub_check(monkeypatch, "pass")
        out = _run_sec_archive(monkeypatch, fake, [url])
        uploaded = base64.b64decode(fake.posts[0]["json"]["data"])
        assert ocr_seen[0] == uploaded, "检的字节与存的字节分家＝检的是一张、存的另一张"
        assert out.kept[0].size == len(uploaded)

    def test_拦下的那张在日志里不许写成下不动(self, channel, monkeypatch, caplog):
        """`Blocked` 是 `SkipImage` 的子类，except 顺序写反了行为不变、日志会变：
        以后有人拿"下不动的那几张"算站点失败率，就会把拦下的违规图一起算进去。"""
        url = "https://a.test/bad.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(600, 600))))
        _sec(monkeypatch)
        _stub_ocr(monkeypatch)
        _stub_check(monkeypatch, "risky")
        with caplog.at_level(logging.INFO, logger="app.services.note_images"):
            _run_sec_archive(monkeypatch, fake, [url])
        msgs = [r.getMessage() for r in caplog.records]
        assert any("内容安全" in m for m in msgs), f"拦下的一张都没标出来：{msgs}"
        assert not any("没存上" in m for m in msgs), "违规图不许混进「站点下不动」那一族"


class Test八之补_worker把真openid递下来:
    def test_归档那一趟用的是库里的openid而不是user_id(self, db, monkeypatch):
        """闸在 archive 里，但 openid 是 worker 现查的——这一条钉的是接线，不是闸。
        传错成 user_id 的话微信回 40003＝没检成＝放行，整条链会绿着什么都不检。"""
        user, _ = _make_user(db)
        grabbed: dict = {}

        async def spy(images, user_id, limit, on_ready=None, *, openid, referer="", user_agent=""):
            grabbed["openid"] = openid
            return note_images.ArchiveResult(kept=[], failed=[], total=len(images))

        monkeypatch.setattr(note_images, "archive", spy)
        monkeypatch.setattr(note_images.settings, "IMAGE_STORE_CF_URL", CF_URL)
        monkeypatch.setattr(note_images.settings, "IMAGE_STORE_CF_KEY", CF_KEY)
        note = Note(user_id=str(user.id), title="外链篇", source_type="wechat_article")
        db.add(note)
        db.commit()
        db.refresh(note)
        scraped = {"images": ["https://a.test/1.jpg"], "author": "someone"}
        ingest_tasks._archive_images(db, note, scraped, str(user.id))
        assert grabbed.get("openid") == user.openid, f"递给内容安全的是 {grabbed.get('openid')!r}，不是那个人的 openid"

    def test_抓取那一层点名的来路要一路递到下载这一步(self, db, monkeypatch):
        """接线钉：`scraper` 在微博那一路写 `image_referer`，worker 把它递给 `archive`。
        中间任何一环漏掉，屏上都是"笔记建好了、图一张没存"，念的还是那句"没存上"——
        而现网读数说这一族不带微博来路时 `wx*.sinaimg.cn` 整批 **403／238 B**（10-31）。
        10-31 第二刀（搜狐）走的是同一根线、另一枚参数 `image_user_agent`：
        那族卡的是我们那枚 Windows 桌面 UA，现网出口九张里 6 张 403、换成点名的那枚九张全 200。"""
        user, _ = _make_user(db)
        grabbed: dict = {}

        async def spy(images, user_id, limit, on_ready=None, *, openid, referer="", user_agent=""):
            grabbed["referer"] = referer
            grabbed["user_agent"] = user_agent
            return note_images.ArchiveResult(kept=[], failed=[], total=len(images))

        monkeypatch.setattr(note_images, "archive", spy)
        monkeypatch.setattr(note_images.settings, "IMAGE_STORE_CF_URL", CF_URL)
        monkeypatch.setattr(note_images.settings, "IMAGE_STORE_CF_KEY", CF_KEY)
        note = Note(user_id=str(user.id), title="微博篇", source_type="web_article")
        db.add(note)
        db.commit()
        db.refresh(note)

        换一枚 = scraper._SOHU_IMAGE_UA
        for 抓取回体, 该递来路, 该递UA in (
                ({"images": ["https://wx1.sinaimg.cn/x.jpg"],
                  "image_referer": "https://m.weibo.cn/"}, "https://m.weibo.cn/", ""),
                ({"images": ["https://q8.itc.cn/a.jpeg"],
                  "image_user_agent": 换一枚}, "", 换一枚),
                ({"images": ["https://mmbiz.qpic.cn/y.jpg"]}, "", ""),
                ({"images": ["https://a.test/z.jpg"],
                  "image_referer": None, "image_user_agent": None}, "", "")):
            grabbed.clear()
            ingest_tasks._archive_images(db, note, 抓取回体, str(user.id))
            assert grabbed.get("referer") == 该递来路, f"{抓取回体} 来路递成 {grabbed.get('referer')!r}"
            assert grabbed.get("user_agent") == 该递UA, f"{抓取回体} UA 递成 {grabbed.get('user_agent')!r}"


def _stub_check_image(monkeypatch, verdict="risky"):
    """画面那道闸的替身：记下载到的字节，按 verdict 回。"""
    seen: list = []

    def _fake(data):
        seen.append(data)
        return verdict

    monkeypatch.setattr(note_images, "check_image", _fake)
    return seen


class Test九_画面本身:
    """站长 10-22 那一句「为什么图片审查没有生效，我导入敏感照片，没有任何提示」。

    读出来的事实：这一条链上只有"图上的字"那道闸，**画面**一行代码都没检过；而涉黄图往往
    一个字都没有，连送检都送不到。这一类钉的是补上的第二道——它必须排在进桶之前，
    并且与文字那道**各自独立**（合成一道，日志就分不出是谁拦的，今天这一趟就是靠这个分别读出来的）。
    """

    def test_画面判违规时这一张不进桶(self, channel, monkeypatch):
        url = "https://a.test/porn.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(600, 600))))
        _sec(monkeypatch)
        checks = _stub_check_image(monkeypatch, "risky")
        out = _run_sec_archive(monkeypatch, fake, [url])
        assert not out.kept and out.failed == [url]
        assert len(checks) == 1
        assert fake.posts == [], "拦下就不该往桶里传：传了就是公开页上摊着一张没人认的图"

    def test_检的是压完那一份字节而不是原件(self, channel, monkeypatch):
        """与文字那道同一条理由：进桶、会出现在公开页上的是压完那一份。"""
        url = "https://a.test/big.jpg"
        raw = _jpeg(3000, 3000)
        fake = _wire(monkeypatch, FakeHttp(_img(url, raw)))
        _sec(monkeypatch)
        checks = _stub_check_image(monkeypatch, "pass")
        _run_sec_archive(monkeypatch, fake, [url])
        assert len(checks) == 1
        assert len(checks[0]) < len(raw), f"送的是 {len(checks[0])} B，原件 {len(raw)} B ⇒ 没压过"

    def test_检不成时放行并留下一句实话(self, channel, monkeypatch, caplog):
        """`unavailable` 是"这次没检成"，不是"这张图没问题"——不许变成"存不下图"。"""
        import logging

        url = "https://a.test/抖动.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(600, 600))))
        _sec(monkeypatch)
        _stub_check_image(monkeypatch, "unavailable")
        with caplog.at_level(logging.ERROR):
            out = _run_sec_archive(monkeypatch, fake, [url])
        assert len(out.kept) == 1, "接口抖一下不该让用户存不下图"
        assert "没检成" in caplog.text and "这不是「图没问题」" in caplog.text

    def test_开关关着时一次都不许多打(self, channel, monkeypatch):
        url = "https://a.test/off.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(600, 600))))
        _sec(monkeypatch, enabled=False)
        checks = _stub_check_image(monkeypatch, "risky")
        _run_sec_archive(monkeypatch, fake, [url])
        assert checks == [], "SEC_CHECK_ENABLED=false 是测试环境的出口，它必须两道都管住"

    def test_画面那道不许把拦下的写成站点下不动(self, channel, monkeypatch, caplog):
        """`Blocked` 是 `SkipImage` 的子类：except 顺序写反了行为不变、日志会变，以后没法归因。"""
        import logging

        url = "https://a.test/bad2.jpg"
        fake = _wire(monkeypatch, FakeHttp(_img(url, _jpeg(600, 600))))
        _sec(monkeypatch)
        _stub_check_image(monkeypatch, "risky")
        with caplog.at_level(logging.INFO):
            _run_sec_archive(monkeypatch, fake, [url])
        assert "被内容安全挡下" in caplog.text, caplog.text
        assert "没存上" not in caplog.text
