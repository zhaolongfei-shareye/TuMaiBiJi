// ---------------------------------------------------------------- 配方解释器
//
// 一份配方就是一段纯 JSON：{ id, min_version, steps: [...] }。步型只有七种
// （let / do / emit / emitOne / emitMany / if / each），表达式只有下面算子表里那些，
// 要量文字的排版动作由外面注入的「原语」做——配方只能挑名字、填参数，不能带代码。
//
// 为什么是解释器而不是"下发 JS 代码"：微信《关于禁止小程序 JavaScript 解释器使用规范》
// 禁止用内置解释器跑远程下发的代码（eval5 / estime / evil-eval 那一类，2022-07-06 起审核执行），
// 允许下发的只有数据。所以下面每一处求值都是手工走树：没有 eval、没有 new Function、
// 没有任何把字符串当代码执行的地方。
//
// 抛错是故意的：名单外的名字一律当场抛。配方写错一个算子，要变成"这张卡画不出来、
// 退回包内那一份"，而不是"少画一层、用户看见一张缺了东西的卡"。
// 数组是"逐项求值后交回一个数组"（行的列表、坐标列表都靠它）；
// 只有网点框那种"解释器不许碰内容、原样交给绘制层"的复合数据才包在 `{"lit": ...}` 里。
// `obj` 是给"数组里每项都是几个字段"的复合数据用的（渐变色标就是 [{at,color}…]）：
// 键名原样留着，键值当表达式求值——色标里的颜色往往要现算（混一档、加一层透明）。
const VERSION = 1

// 算术：-1 是变长（'+ - * min max' 都按 JS 里的写法一路连着算，`a + b + c` 不用套三层）。
// 非整数结果照原样留着——画布坐标本来就允许小数，取不取整是配方自己的事（用 round）。
const ARITH = { '+': -1, '-': -1, '*': -1, '/': 2, '%': 2, min: -1, max: -1, round: 1, floor: 1, ceil: 1, abs: 1, neg: 1 }
const LOGIC = { '<': 2, '<=': 2, '>': 2, '>=': 2, '==': 2, '!=': 2, and: -1, or: -1, not: 1, len: 1, truthy: 1 }
// 类型转换只有三条：
// `str` —— 图层里的 lines 是字符串数组，交个数进去画面上看着一样、清单却是 number 与 string 两种；
// `padStart` —— 规格卡那个「01 / 02」序号；`slice` —— 竖排那一列只取前十个字。
const CONV = { str: 1, padStart: 2, slice: 3 }
const STEPS = ['let', 'do', 'emit', 'emitOne', 'emitMany', 'if', 'each']
// 项形：不是算子，是"一项能长成哪几种骨架"。导出给后端那份名单对表用（docs/工具/出-模板配方种子.js），
// 加了一种形却忘了同步，服务端就会放行一份客户端读不懂的配方。
const TERM_FORMS = ['var', 'lit', 'if', 'obj', 'prim', 'list']
// 一条配方能有多大。解释器对"内容有多大"本来不设防，一条十万步的配方会让出图那一次
// 主线程全卡在测量上——所以两头都要拦：下发前服务端拦一道，渲染前这里再拦一道。
// 这三个数与 backend/app/services/poster_recipe.py 里那份必须相等，两边都由
// backend/seed/poster_whitelist.json 对齐（尺子 验-模板配方可执行.js 与 pytest 各查一头）。
// 参照：包内这十套实测峰值 6,383 字节 / 深 17 层 / 691 个节点，所以三条都留了两三倍。
const LIMITS = { max_bytes: 16384, max_depth: 24, max_nodes: 2000 }

// 按键名排序后的紧凑 JSON——与后端 `canonical_json` 同一个写法。三条上界量的是这个字节数，
// 也正因为两边都算这一个字符串，服务端放行的尺寸和客户端认的尺寸才是同一个数。
function canonJson(v) {
  if (Array.isArray(v)) return `[${v.map(canonJson).join(',')}]`
  if (v !== null && typeof v === 'object') {
    return `{${Object.keys(v).sort().map((k) => `${JSON.stringify(k)}:${canonJson(v[k])}`).join(',')}}`
  }
  return JSON.stringify(v)
}

// 小程序里没有 Buffer，UTF-8 字节数自己数。代理对算 4 字节（与 Python 的 encode('utf-8') 一致），
// 否则含 emoji 的配方两边会数出两个数来。
function utf8Bytes(s) {
  let n = 0
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i)
    if (c < 0x80) n += 1
    else if (c < 0x800) n += 2
    else if (c >= 0xd800 && c <= 0xdbff && i + 1 < s.length && s.charCodeAt(i + 1) >= 0xdc00 && s.charCodeAt(i + 1) <= 0xdfff) { n += 4; i++ }
    else n += 3
  }
  return n
}

// 深度/节点数的数法与后端 `_depth`/`_nodes` 逐字对齐：数组与对象各算一层，对象数键的个数、
// 数组数个儿的个数，标量不算节点。两边数法不一样＝同一份配方一个放行一个拦。
function sizeOf(recipe) {
  const count = (v) => {
    const isList = Array.isArray(v)
    const isMap = !isList && v !== null && typeof v === 'object'
    if (!isList && !isMap) return { d: 0, n: 0 }
    const kids = isList ? v : Object.keys(v).map((k) => v[k])
    let d = 0
    let n = kids.length
    kids.forEach((x) => {
      const r = count(x)
      if (r.d > d) d = r.d
      n += r.n
    })
    return { d: d + 1, n }
  }
  const w = count(recipe)
  return { bytes: utf8Bytes(canonJson(recipe)), depth: w.d, nodes: w.n }
}

function describe(v) {
  if (v === null) return 'null'
  if (Array.isArray(v)) return '数组'
  const ty = typeof v
  if (ty === 'object') return '对象'
  if (ty === 'string') return `「${v}」`
  return String(v)
}

// 项的形状。求值和静态检查共用这一份，免得两条路各认一套写法。
function shape(t) {
  if (t === null || typeof t === 'number' || typeof t === 'string' || typeof t === 'boolean') return { kind: 'lit', v: t }
  if (typeof t !== 'object') return { kind: 'err', e: `不成形的值（${describe(t)}）` }
  if (Array.isArray(t)) return { kind: 'list', v: t }
  if (t.prim !== undefined) {
    if (typeof t.prim !== 'string') return { kind: 'err', e: 'prim 得是个名字' }
    const extra = Object.keys(t).filter((k) => k !== 'prim' && k !== 'args')
    if (extra.length) return { kind: 'err', e: `原语那一项里多了 ${extra.join('、')}` }
    const args = t.args === undefined ? {} : t.args
    if (args === null || typeof args !== 'object' || Array.isArray(args)) return { kind: 'err', e: `原语「${t.prim}」的 args 得是个对象` }
    return { kind: 'prim', name: t.prim, args }
  }
  if (t.obj !== undefined) {
    const extra = Object.keys(t).filter((k) => k !== 'obj')
    if (extra.length) return { kind: 'err', e: `obj 那一项里多了 ${extra.join('、')}` }
    if (t.obj === null || typeof t.obj !== 'object' || Array.isArray(t.obj)) return { kind: 'err', e: 'obj 得是个键值对象' }
    return { kind: 'obj', fields: t.obj }
  }
  const keys = Object.keys(t)
  if (keys.length !== 1) return { kind: 'err', e: `只能有一个键，这里有 ${keys.length} 个：${keys.join('、')}` }
  return { kind: 'op', name: keys[0], a: t[keys[0]] }
}

function lookup(scope, path) {
  if (typeof path !== 'string' || !path) throw new Error(`变量名得是个非空字符串，拿到 ${describe(path)}`)
  let cur = scope
  for (const seg of path.split('.')) {
    if (cur === null || typeof cur !== 'object') return null
    // 只认自有的键：`note.constructor`、`x.__proto__` 这类原型链上的东西一律当没有。
    // 配方是外来的数据，能顺着原型链摸到函数对象就等于摸到了代码执行面，这条路要堵死。
    if (!Object.prototype.hasOwnProperty.call(cur, seg)) return null
    cur = cur[seg]
  }
  return cur === undefined ? null : cur
}

function num(v, where) {
  // 只有真的算得出数才往下走：配方里写错一个变量名会读到 null，
  // Number(null) 是 0，不拦就成了"少 0 个像素"的静默错位。undefined 才 NaN。
  const n = typeof v === 'number' ? v : Number(v)
  if (!Number.isFinite(n)) throw new Error(`${where}: 要一个数，拿到 ${describe(v)}`)
  return n
}

function arity(name, want, got, where) {
  if (want >= 0 && got !== want) throw new Error(`${where}: 算子「${name}」要 ${want} 个参数，给了 ${got} 个`)
  // 变长算子至少得有一个：`{"+": []}` 会 reduce 成 0，那是"坐标掉回原点"，不是"没加"
  if (want < 0 && got < 1) throw new Error(`${where}: 算子「${name}」至少要一个参数`)
}

function callOp(name, a, env, scope, where) {
  if (name === 'var') {
    // 根名字必须在场：写错一个变量名要立刻抛，不能让它当成 null 往下算——
    // Number(null) 是 0，那就成了"少 0 个像素"的静默错位。
    const root = String(a).split('.')[0]
    if (!Object.prototype.hasOwnProperty.call(scope, root)) throw new Error(`${where}: 还没算出变量「${a}」`)
    return lookup(scope, a)
  }
  if (name === 'lit') return a
  if (name === 'if') {
    if (!Array.isArray(a) || a.length !== 3) throw new Error(`${where}: if 要 [条件, 真, 假] 三个参数`)
    return truthy(ev(a[0], env, scope, `${where} if`)) ? ev(a[1], env, scope, `${where} if`) : ev(a[2], env, scope, `${where} if`)
  }
  const args = (Array.isArray(a) ? a : [a]).map((x, i) => ev(x, env, scope, `${where} ${name}[${i}]`))
  if (ARITH[name] !== undefined) {
    arity(name, ARITH[name], args.length, where)
    const n = args.map((x) => num(x, `${where} ${name}`))
    switch (name) {
      case '+': return n.reduce((x, y) => x + y)
      case '-': return n.reduce((x, y) => x - y)
      case '*': return n.reduce((x, y) => x * y)
      case '/': return n[0] / n[1]
      case '%': return n[0] % n[1]
      case 'min': return Math.min(...n)
      case 'max': return Math.max(...n)
      case 'round': return Math.round(n[0])
      case 'floor': return Math.floor(n[0])
      case 'ceil': return Math.ceil(n[0])
      case 'abs': return Math.abs(n[0])
      default: return -n[0]
    }
  }
  if (CONV[name] !== undefined) {
    arity(name, CONV[name], args.length, where)
    const s = String(args[0] == null ? '' : args[0])
    switch (name) {
      case 'str': return s
      case 'padStart': return s.padStart(num(args[1], `${where} padStart`), '0')
      default: return s.slice(num(args[1], `${where} slice`), num(args[2], `${where} slice`))
    }
  }
  if (LOGIC[name] !== undefined) {
    arity(name, LOGIC[name], args.length, where)
    switch (name) {
      case '<': return args[0] < args[1]
      case '<=': return args[0] <= args[1]
      case '>': return args[0] > args[1]
      case '>=': return args[0] >= args[1]
      case '==': return args[0] === args[1]
      case '!=': return args[0] !== args[1]
      case 'and': return args.every(truthy)
      case 'or': return args.some(truthy)
      case 'not': return !truthy(args[0])
      // 字符串按码点计数（和 planner 里那句 `Array.from(vertText).length` 同一条口径），
      // 按 UTF-16 长度数会在 emoji 上少数。
      case 'len': return Array.isArray(args[0]) ? args[0].length : Array.from(String(args[0] == null ? '' : args[0])).length
      default: return truthy(args[0])
    }
  }
  throw new Error(`${where}: 不认的算子「${name}」`)
}

function truthy(v) {
  if (v === null || v === undefined || v === '' || v === false) return false
  if (typeof v === 'number') return v !== 0
  if (Array.isArray(v)) return v.length > 0
  return true
}

function ev(term, env, scope, where) {
  const s = shape(term)
  if (s.kind === 'err') throw new Error(`${where}: ${s.e}`)
  if (s.kind === 'lit') return s.v
  if (s.kind === 'list') return s.v.map((x, i) => ev(x, env, scope, `${where}[${i}]`))
  if (s.kind === 'prim') return env.callPrim(s.name, s.args, scope)
  if (s.kind === 'obj') {
    const o = {}
    Object.keys(s.fields).forEach((k) => { o[k] = ev(s.fields[k], env, scope, `${where} obj.${k}`) })
    return o
  }
  return callOp(s.name, s.a, env, scope, where)
}

// 步的形状。`let` 是唯一带两个键的步型（变量名和它的值本来就是一件事的两半），
// 其余一步一个键。求值和静态检查共用这一份。
function stepShape(raw) {
  if (raw === null || typeof raw !== 'object' || Array.isArray(raw)) return { err: '一步得是个对象' }
  if (raw.let !== undefined) {
    const extra = Object.keys(raw).filter((k) => k !== 'let' && k !== 'value')
    if (extra.length) return { err: `let 那一步里多了 ${extra.join('、')}` }
    if (typeof raw.let !== 'string' || !raw.let) return { err: 'let 要给一个变量名' }
    if (!('value' in raw)) return { err: `let「${raw.let}」少了 value` }
    return { kind: 'let', name: raw.let, value: raw.value }
  }
  const keys = Object.keys(raw)
  if (keys.length !== 1) return { err: `一步只能有一个键，这里有 ${keys.length} 个：${keys.join('、')}` }
  const kind = keys[0]
  if (STEPS.indexOf(kind) < 0) return { err: `不认的步型「${kind}」，能用的是 ${STEPS.join('、')}` }
  return { kind, a: raw[kind] }
}

function runStep(step, env, scope, where) {
  const s = stepShape(step)
  if (s.err) throw new Error(`${where}: ${s.err}`)
  const kind = s.kind
  const a = s.a
  if (kind === 'let') {
    scope[s.name] = ev(s.value, env, scope, `${where} let ${s.name}`)
    return
  }
  if (kind === 'do') {
    // 只求值、不绑定：planner 里那句"先切到这一档字号，再按三元决定要不要量字"
    // 切字体在分支外面，配方得能原样记下这一步（逐层等价把每一次 ctx 写入都算进去了）。
    ev(a, env, scope, `${where} do`)
    return
  }
  if (kind === 'emit') {
    // 字段值全是表达式，先逐个求值再交给外面那层构造真图层；`k` 是 op 名字，
    // 必须写死成字符串——允许它是表达式等于允许配方自己造 op 名。
    if (a === null || typeof a !== 'object' || Array.isArray(a)) throw new Error(`${where}: emit 要给一个图层对象`)
    if (typeof a.k !== 'string') throw new Error(`${where}: emit 少了 op 名（k）`)
    const fields = {}
    Object.keys(a).forEach((k) => { fields[k] = k === 'k' ? a[k] : ev(a[k], env, scope, `${where} ${a.k}.${k}`) })
    env.layers.push(env.buildLayer(fields))
    return
  }
  if (kind === 'emitOne' || kind === 'emitMany') {
    const v = ev(a, env, scope, `${where} ${kind}`)
    if (kind === 'emitOne') {
      env.layers.push(env.checkLayer(v, where))
      return
    }
    if (!Array.isArray(v)) throw new Error(`${where}: emitMany 要一个图层数组，拿到 ${describe(v)}`)
    v.forEach((l) => env.layers.push(env.checkLayer(l, where)))
    return
  }
  if (kind === 'if') {
    if (!truthy(ev(a.cond, env, scope, `${where} if`))) {
      if (a.else) runSteps(a.else, env, scope, `${where} else`)
      return
    }
    runSteps(a.then, env, scope, `${where} then`)
    return
  }
  // 循环：over 给数组，as 收元素，index 收序号（不给就不占名字）。
  // 要点那一段是"逐条 clip 再逐条落笔"，没有这一步就得把条数写死在配方里。
  const list = ev(a.over, env, scope, `${where} each`)
  if (!Array.isArray(list)) throw new Error(`${where}: each 的对象得是个数组，拿到 ${describe(list)}`)
  // 每轮一个新的内层 scope：循环体里 let 出来的东西不回写外层，
  // 否则第二轮会读到上一轮的数（要点那段每轮都要重算 y）。
  list.forEach((item, i) => {
    const inner = Object.assign({}, scope)
    inner[a.as] = item
    if (a.index) inner[a.index] = i
    runSteps(a.do, env, inner, `${where} each#${i + 1}`)
  })
}

function runSteps(steps, env, scope, where) {
  if (!Array.isArray(steps)) throw new Error(`${where}: steps 得是个数组`)
  steps.forEach((s, i) => runStep(s, env, scope, `${where} 第 ${i + 1} 步`))
}

// 静态检查：不执行，只走形状与名单。必须在执行之前跑完，因为它查的是
// "这一版客户端根本读不了的配方"和"跑起来才会踩到的死分支"——比如 if 的 else
// 里藏一个不认的 op，这一篇笔记恰好不走 else，错误就会溜到真机上线后才出现。
function scanTerm(t, allow, bad, where) {
  const s = shape(t)
  if (s.kind === 'err') { bad.push(`${where}: ${s.e}`); return }
  if (s.kind === 'lit') return
  if (s.kind === 'list') { s.v.forEach((x, i) => scanTerm(x, allow, bad, `${where}[${i}]`)); return }
  if (s.kind === 'prim') {
    if (!allow.primKeys[s.name]) { bad.push(`${where}: 原语「${s.name}」不在名单里`); return }
    Object.keys(s.args).forEach((k) => {
      if (allow.primKeys[s.name].indexOf(k) < 0) bad.push(`${where}: 原语「${s.name}」没有参数「${k}」，能用的是 ${allow.primKeys[s.name].join('、')}`)
    })
    Object.keys(s.args).forEach((k) => scanTerm(s.args[k], allow, bad, `${where} ${s.name}.${k}`))
    return
  }
  if (s.kind === 'obj') {
    Object.keys(s.fields).forEach((k) => scanTerm(s.fields[k], allow, bad, `${where} obj.${k}`))
    return
  }
  const name = s.name
  if (name === 'var' || name === 'lit') {
    if (name === 'var' && (typeof s.a !== 'string' || !s.a)) bad.push(`${where}: var 得是个名字`)
    return
  }
  if (name === 'if') {
    if (!Array.isArray(s.a) || s.a.length !== 3) { bad.push(`${where}: if 要 [条件, 真, 假] 三个参数`); return }
    s.a.forEach((x, i) => scanTerm(x, allow, bad, `${where} if[${i}]`))
    return
  }
  if (ARITH[name] !== undefined || LOGIC[name] !== undefined || CONV[name] !== undefined) {
    const want = ARITH[name] !== undefined ? ARITH[name] : (LOGIC[name] !== undefined ? LOGIC[name] : CONV[name])
    const args = Array.isArray(s.a) ? s.a : [s.a]
    if (want >= 0 && args.length !== want) bad.push(`${where}: 算子「${name}」要 ${want} 个参数，给了 ${args.length} 个`)
    if (want < 0 && args.length < 1) bad.push(`${where}: 算子「${name}」至少要一个参数`)
    args.forEach((x, i) => scanTerm(x, allow, bad, `${where} ${name}[${i}]`))
    return
  }
  bad.push(`${where}: 不认的算子「${name}」`)
}

function scanSteps(steps, allow, bad, where) {
  if (!Array.isArray(steps)) { bad.push(`${where}: steps 得是个数组`); return }
  steps.forEach((raw, i) => {
    const at = `${where} 第 ${i + 1} 步`
    const s = stepShape(raw)
    if (s.err) { bad.push(`${at}: ${s.err}`); return }
    const kind = s.kind
    const a = s.a
    if (kind === 'let') { scanTerm(s.value, allow, bad, `${at} ${s.name}`); return }
    if (kind === 'do') { scanTerm(a, allow, bad, `${at} do`); return }
    if (kind === 'emit') {
      if (a === null || typeof a !== 'object' || Array.isArray(a)) { bad.push(`${at}: emit 要给一个图层对象`); return }
      const op = a.k
      if (!allow.opKeys[op]) { bad.push(`${at}: 绘制 op「${op === undefined ? '（没写 k）' : op}」不在名单里`); return }
      Object.keys(a).forEach((k) => {
        if (k === 'k') return
        if (allow.opKeys[op].indexOf(k) < 0) bad.push(`${at}: op「${op}」没有字段「${k}」，能用的是 ${allow.opKeys[op].join('、')}`)
        scanTerm(a[k], allow, bad, `${at} ${op}.${k}`)
      })
      return
    }
    if (kind === 'emitOne' || kind === 'emitMany') { scanTerm(a, allow, bad, `${at} ${kind}`); return }
    if (kind === 'if') {
      if (a === null || typeof a !== 'object') { bad.push(`${at}: if 要给 {cond, then, else}`); return }
      scanTerm(a.cond, allow, bad, `${at} if.cond`)
      scanSteps(a.then, allow, bad, `${at} if.then`)
      if (a.else) scanSteps(a.else, allow, bad, `${at} if.else`)
      Object.keys(a).forEach((k) => { if (['cond', 'then', 'else'].indexOf(k) < 0) bad.push(`${at}: if 项里多了 ${k}`) })
      return
    }
    if (a === null || typeof a !== 'object') { bad.push(`${at}: each 要给 {over, as, index, do}`); return }
    scanTerm(a.over, allow, bad, `${at} each.over`)
    if (typeof a.as !== 'string' || !a.as) bad.push(`${at}: each 少了 as`)
    scanSteps(a.do, allow, bad, `${at} each.do`)
    Object.keys(a).forEach((k) => { if (['over', 'as', 'index', 'do'].indexOf(k) < 0) bad.push(`${at}: each 项里多了 ${k}`) })
  })
}

// 哪几种步型真的往画布上落笔：`runStep` 里只有这三条会 push env.layers。
// `let`／`do` 只算数，`if`／`each` 自己不产层——层在它们体内，所以找第一笔要钻进体里按执行顺序走。
const PAINT_STEPS = ['emit', 'emitOne', 'emitMany']

function paintStepsIn(steps, out) {
  if (!Array.isArray(steps)) return out
  steps.forEach((raw) => {
    const s = stepShape(raw)
    if (s.err) return
    if (PAINT_STEPS.indexOf(s.kind) >= 0) { out.push(s); return }
    if (s.kind === 'if') {
      paintStepsIn(s.a && s.a.then, out)
      paintStepsIn(s.a && s.a.else, out)
      return
    }
    if (s.kind === 'each') paintStepsIn(s.a && s.a.do, out)
  })
  return out
}

// "整幅底"怎么判——判据全从调用方交回来的那张 op 字段表（poster.js 的 RECIPE_OP_KEYS，
// 出处是 paintLayers 里每个 case 真正读的 ly.xxx）现读，这里不另立一份 op 名单：
// 字段表同时含 x、y、w、h 又不含圆角 r 的，paintLayers 才会拿一次 plain fillRect 把那块矩形铺满
//（今天恰好是 fill 与 grad 两枚；rrect／image 带 r 会露四角、dots 带 r 又只铺点、
//  radial 铺的是 box 而不是 w／h、circle／line／text／avatar 更盖不住整幅）。
// 坐标要写死成 0,0、w 取 var W、h 取 var height：包内十套的起手层全是这一笔，
// 也只有 `emit` 这种几何写成字面量的步能静态证"铺满"——emitOne／emitMany 的层是原语跑出来才知道的。
function isFullBleedBase(s, opKeys) {
  if (s.kind !== 'emit') return false
  const a = s.a
  if (!a || typeof a !== 'object' || Array.isArray(a)) return false
  const keys = opKeys[a.k]
  if (!keys) return false
  if (['x', 'y', 'w', 'h'].some((n) => keys.indexOf(n) < 0)) return false
  if (keys.indexOf('r') >= 0) return false
  const isVar = (v, n) => {
    if (v === null || typeof v !== 'object' || Array.isArray(v)) return false
    const ks = Object.keys(v)
    return ks.length === 1 && ks[0] === 'var' && v.var === n
  }
  return a.x === 0 && a.y === 0 && isVar(a.w, 'W') && isVar(a.h, 'height')
}

// 返回错误清单（空数组＝这份配方这个客户端读得懂）。写回接口、下发前、渲染前都用它。
function validate(recipe, allow) {
  const bad = []
  if (recipe === null || typeof recipe !== 'object' || Array.isArray(recipe)) return ['配方得是个 JSON 对象']
  if (typeof recipe.id !== 'string' || !recipe.id) bad.push('少了 id')
  const mv = recipe.min_version
  if (!Number.isInteger(mv) || mv < 1) bad.push('min_version 得是 ≥1 的整数')
  else if (mv > VERSION) bad.push(`这份配方要 ${mv} 版解释器，这份客户端只会读到 ${VERSION} 版`)
  if (!Array.isArray(recipe.steps) || !recipe.steps.length) bad.push('steps 得是非空数组')
  else {
    scanSteps(recipe.steps, allow, bad, 'steps')
    // 画布多高只有这一处能说：planFromRecipe 拿 scope.height 当成品高度，
    // 少这一步就是每张卡都塌成同一档，而那正是几何自检查得出的第一条。
    if (!recipe.steps.some((s) => s && typeof s === 'object' && s.let === 'height')) bad.push('steps 里必须有一步 let 出 height')
    // 上面那条只钉住"画布多高有人说了算"，钉不住"这套到底画不画东西"：
    // 一份只有 let 的配方能过全部名单校验、跑出 750×800 零层的空卡，闸门照收（审计 N11）。
    // 守"整套能用才用"——不合格就整行拒，不做"跳过这一层继续画"。
    const opKeys = (allow && allow.opKeys) || {}
    const paints = paintStepsIn(recipe.steps, [])
    if (!paints.length) bad.push('steps 里没有一笔真的落笔（只有 let／do 的配方撑得出画布却画不出东西）')
    else if (!isFullBleedBase(paints[0], opKeys)) bad.push('第一笔不是盖住整张卡的底（要一步 emit 一个 x=0、y=0、w 为 var W、h 为 var height 的实心矩形层）')
  }
  // 三条上界放在最后：就算形状全错，尺寸也要量——否则一份"合法但十万步"的配方
  // 会在渲染那一次把主线程吃干。这三条与后端 validate_recipe 那三条是同一道闸门的两头。
  const sz = sizeOf(recipe)
  if (sz.bytes > LIMITS.max_bytes) bad.push(`整条配方 ${sz.bytes} 字节，超过上限 ${LIMITS.max_bytes}`)
  if (sz.depth > LIMITS.max_depth) bad.push(`嵌套 ${sz.depth} 层，超过上限 ${LIMITS.max_depth}`)
  if (sz.nodes > LIMITS.max_nodes) bad.push(`${sz.nodes} 个节点，超过上限 ${LIMITS.max_nodes}`)
  return bad
}

// env = { scope, prims: {name: {keys, call}}, opKeys, buildLayer, checkLayer, layers }
function planFromRecipe(recipe, env) {
  const primKeys = {}
  Object.keys(env.prims).forEach((n) => { primKeys[n] = env.prims[n].keys })
  const bad = validate(recipe, { opKeys: env.opKeys, primKeys })
  if (bad.length) throw new Error(`配方「${(recipe && recipe.id) || '?'}」不合格：${bad.join('；')}`)
  const scope = Object.assign({}, env.scope)
  runSteps(recipe.steps, env, scope, 'steps')
  const h = num(scope.height, 'height')
  if (!(h > 0)) throw new Error(`配方「${recipe.id}」算出的画布高度不合法：${h}`)
  return { width: env.width, height: h, layers: env.layers, template: recipe.id }
}

module.exports = { VERSION, ARITH, LOGIC, CONV, STEPS, TERM_FORMS, LIMITS, sizeOf, planFromRecipe, validate, truthy, evalTerm: ev }
